/**
 * 3D Birthday Celebration - Romantic Girlfriend Edition
 */

document.addEventListener('DOMContentLoaded', () => {
  const scene = new BirthdayScene('canvas-container');
  window.birthdayScene = scene;

  // Dynamic API Base URL: Works locally (port 8000 -> 5000) and automatically on Render (origin)
  const API_BASE = (window.location.protocol.startsWith('http'))
    ? ((window.location.port === '8000' || window.location.port === '3000' || window.location.port === '5500')
        ? 'http://localhost:5000'
        : window.location.origin)
    : 'http://localhost:5000';

  // SECURITY: Resolve photo URLs to the token-free proxy.
  // - New proxy URLs look like "/api/photo?file_id=..." -> prefix with API_BASE.
  // - Legacy direct Telegram CDN URLs (api.telegram.org/file/bot<TOKEN>/...)
  //   are converted client-side to the proxy so the bot token is never used
  //   in the browser (covers cached localStorage data from older links).
  function resolvePhotoUrl(u) {
    if (!u || typeof u !== 'string') return u;
    const s = u.trim();
    if (!s) return s;
    if (s.startsWith('data:') || s.startsWith('blob:')) return s;
    if (s.startsWith('/api/photo')) return API_BASE + s;
    const tgMatch = s.match(/^https?:\/\/api\.telegram\.org\/file\/bot[^/]+\/(.+)$/);
    if (tgMatch && tgMatch[1]) {
      return API_BASE + '/api/photo?p=' + encodeURIComponent(tgMatch[1]);
    }
    return s;
  }

  // App State - Romantic Defaults
  let celebrantName = 'My Love';
  let celebrantAge = '';
  let customWish = 'Happy Birthday to the most amazing, gorgeous, and loving girl in the whole world! Thank you for bringing endless joy, warmth, and magic into my life. Every single day with you is my favorite day. May all your sweetest dreams come true today and forever!';
  let activeTheme = 'rose-glamour';
  let celebrantFont = 'outfit'; // New: selected name font style

  // Security: the session token proves the client authenticated with the API.
  // null = not authenticated. Set after successful login, cleared on logout.
  let apiAuthToken = null;

  // Story Flow Steps: 'intro' -> 'balloons' -> 'burn-candles' -> 'cut-cake' -> 'open-gift' -> 'free-play'
  let currentStoryStep = 'intro';
  let currentPortalUser = null; // tracks logged-in username key
  let selectedCreatorMode = 'gf';
  let currentPhotoDataUrl = null;
  let userMemoriesPhotos = [];

  // DOM Elements
  const curtainContainer = document.getElementById('curtain-container');
  const portalLandingScreen = document.getElementById('portal-landing-screen');
  const portalCreatorDashboard = document.getElementById('portal-creator-dashboard');

  // --- IMMEDIATE ROUTE ENFORCEMENT (Zero Flash of Documentation / Zero Flash of 3D Cake) ---
  (function enforceImmediateRoute() {
    const params = new URLSearchParams(window.location.search || window.location.hash.replace(/^#/, '?'));
    const isDirectSurpriseLink = params.has('s') || params.has('surprise') || params.has('name') || params.has('preview') || params.has('demo');
    let savedSession = null;
    try { savedSession = localStorage.getItem('birthday_portal_session'); } catch(e) {}

    if (isDirectSurpriseLink) {
      if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
      if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      if (curtainContainer) {
        curtainContainer.style.display = 'flex';
        curtainContainer.classList.remove('opened');
      }
      document.documentElement.classList.add('route-surprise-curtain');
      document.documentElement.classList.remove('route-creator-dashboard', 'route-portal-landing');
    } else if (savedSession) {
      if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
      if (curtainContainer) {
        curtainContainer.style.display = 'none';
        curtainContainer.classList.remove('opened');
      }
      if (portalCreatorDashboard) portalCreatorDashboard.classList.remove('hidden');
      document.documentElement.classList.add('route-creator-dashboard');
      document.documentElement.classList.remove('route-surprise-curtain', 'route-portal-landing');
    } else {
      if (curtainContainer) {
        curtainContainer.style.display = 'none';
        curtainContainer.classList.remove('opened');
      }
      if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      if (portalLandingScreen) {
        portalLandingScreen.classList.remove('hidden');
        portalLandingScreen.style.display = 'flex';
      }
      document.documentElement.classList.add('route-portal-landing');
      document.documentElement.classList.remove('route-surprise-curtain', 'route-creator-dashboard');
    }
  })();

  const btnStartCelebration = document.getElementById('btn-start-celebration');
  const guidedStoryBar = document.getElementById('guided-story-bar');
  const mainScreenQuestCard = document.getElementById('main-screen-quest-card');
  const questTitleText = document.getElementById('quest-title-text');
  const questDescText = document.getElementById('quest-desc-text');
  const questBalloonCount = document.getElementById('quest-balloon-count');
  const stepBurnCandles = document.getElementById('step-burn-candles');
  const stepCutCake = document.getElementById('step-cut-cake');
  const stepOpenGift = document.getElementById('step-open-gift');
  const tapGiftCard = document.getElementById('tap-gift-card');
  const freePlayBottomBar = document.getElementById('free-play-bottom-bar');

  // Top Nav & Menu Drawer
  const mainMenuBtn = document.getElementById('main-menu-btn');
  const closeMenuBtn = document.getElementById('close-menu-btn');
  const menuDrawer = document.getElementById('menu-drawer');
  const menuDrawerBackdrop = document.getElementById('menu-drawer-backdrop');

  const displayNameText = document.getElementById('display-name-text');
  const displayAgeBadge = document.getElementById('display-age-badge');
  const celebrantTitle = document.getElementById('celebrant-title');
  const giftCustomWish = document.getElementById('gift-custom-wish');
  const bannerTitle = document.getElementById('banner-title');
  const musicToggleBtn = document.getElementById('music-toggle-btn');
  const soundWave = document.getElementById('sound-wave');
  const quickPetalsBtn = document.getElementById('quick-petals-btn');

  const customizeBtn = document.getElementById('customize-btn');
  const customizeModal = document.getElementById('customize-modal');
  const closeCustomizeModal = document.getElementById('close-customize-modal');
  const customizeForm = document.getElementById('customize-form');
  const inputName = document.getElementById('input-name');
  const inputAge = document.getElementById('input-age');
  const inputWish = document.getElementById('input-wish');
  const inputPhoto = document.getElementById('input-photo');
  const photoFilename = document.getElementById('photo-filename');
  const inputPhotoUrl = document.getElementById('input-photo-url');
  const photoUploadStatus = document.getElementById('photo-upload-status');

  const shareBtn = document.getElementById('share-btn');
  const shareModal = document.getElementById('share-modal');
  const closeShareModal = document.getElementById('close-share-modal');
  const shareLinkInput = document.getElementById('share-link-input');
  const btnCopyLink = document.getElementById('btn-copy-link');
  const copyFeedback = document.getElementById('copy-feedback');
  const qrcodeContainer = document.getElementById('qrcode-container');
  let qrcodeInstance = null;

  const giftModal = document.getElementById('gift-modal');
  const closeGiftModal = document.getElementById('close-gift-modal');
  const btnGiftGoToOrders = document.getElementById('btn-gift-go-to-orders');
  const btnGiftReplay = document.getElementById('btn-gift-replay-fireworks');

  // Romantic Modals & Buttons
  const polaroidsModal = document.getElementById('polaroids-modal');
  const closePolaroidsModal = document.getElementById('close-polaroids-modal');
  const btnMemoryGallery = document.getElementById('btn-memory-gallery');
  const btnOpenCustomizerFromPolaroids = document.getElementById('btn-open-customizer-from-polaroids');
  const btnLoveLetter = document.getElementById('btn-love-letter');

  // Feature buttons (inside drawer)
  const btnSparklerWand = document.getElementById('btn-sparkler-wand');
  const btnArcadeGame = document.getElementById('btn-arcade-game');
  const btnSkyLanterns = document.getElementById('btn-sky-lanterns');
  const btnPhotoBooth = document.getElementById('btn-photo-booth');

  // Free play bottom buttons
  const btnBlowCandles = document.getElementById('btn-blow-candles');
  const btnLaunchFireworks = document.getElementById('btn-launch-fireworks');
  const btnOpenGift = document.getElementById('btn-open-gift');
  const btnSpawnBalloons = document.getElementById('btn-spawn-balloons');

  // Arcade elements
  const arcadeHud = document.getElementById('arcade-hud');
  const arcadeScoreVal = document.getElementById('arcade-score');
  const arcadeTimerVal = document.getElementById('arcade-timer');
  const arcadeComboVal = document.getElementById('arcade-combo');
  const arcadeTimerFill = document.getElementById('arcade-timer-fill');
  const btnQuitArcade = document.getElementById('btn-quit-arcade');
  const arcadeOverModal = document.getElementById('arcade-over-modal');
  const finalScoreVal = document.getElementById('final-score-val');
  const finalRankBadge = document.getElementById('final-rank-badge');
  const btnReplayArcade = document.getElementById('btn-replay-arcade');
  const btnCloseArcadeModal = document.getElementById('btn-close-arcade-modal');

  // Photo Booth Modal
  const photoBoothModal = document.getElementById('photo-booth-modal');
  const closePhotoModal = document.getElementById('close-photo-modal');
  const postcardPreviewImg = document.getElementById('postcard-preview-img');
  const btnDownloadPostcard = document.getElementById('btn-download-postcard');

  // Camera buttons (inside drawer)
  const camPills = {
    orbit: document.getElementById('cam-orbit'),
    cake: document.getElementById('cam-cake'),
    gift: document.getElementById('cam-gift'),
    fireworks: document.getElementById('cam-fireworks'),
  };

  // Sparkler Canvas Init
  const sparklerCanvas = document.getElementById('sparkler-canvas');
  if (sparklerCanvas) {
    sparklerCanvas.width = window.innerWidth;
    sparklerCanvas.height = window.innerHeight;
  }

  /* =========================================================
     RISING HEART BALLOONS WITH GLITTER IN LEFT & RIGHT OPEN AREAS
     (Helium Heart Balloons Rising Upwards in Left & Right Open Wings with Glitter)
     ========================================================= */
  const petalsCanvas = document.getElementById('rose-petals-canvas');
  let petalsEnabled = true;
  let heartBalloonsList = [];
  let balloonSparkleDust = [];

  function drawHeartBalloon(ctx, x, y, size, color, rotation, sparklePhase) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);

    // 1. Hanging String with gentle natural buoyancy curve
    ctx.strokeStyle = 'rgba(255, 205, 218, 0.75)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(0, size * 0.6);
    ctx.quadraticCurveTo(Math.sin(sparklePhase) * 6, size * 1.3, Math.sin(sparklePhase * 0.8) * 4, size * 1.9);
    ctx.stroke();

    // 2. Balloon Tie / Knot
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(-size * 0.1, size * 0.63);
    ctx.lineTo(size * 0.1, size * 0.63);
    ctx.lineTo(0, size * 0.55);
    ctx.closePath();
    ctx.fill();

    // 3. 3D Heart Balloon Body (Plump, beautiful romantic curve)
    ctx.beginPath();
    const topH = size * 0.38;
    ctx.moveTo(0, topH * 0.35);
    ctx.bezierCurveTo(
      -size * 0.52, -topH * 0.95,
      -size * 0.68, topH * 0.35,
      0, size * 0.58
    );
    ctx.bezierCurveTo(
      size * 0.68, topH * 0.35,
      size * 0.52, -topH * 0.95,
      0, topH * 0.35
    );
    ctx.closePath();

    // 3D Glossy Metallic Shading Gradient
    const grad = ctx.createRadialGradient(-size * 0.16, -size * 0.12, 0, 0, 0, size * 0.65);
    grad.addColorStop(0, '#ffffff'); // bright gloss highlight
    grad.addColorStop(0.2, '#ffe0ea');
    grad.addColorStop(0.45, color);
    grad.addColorStop(0.92, color);
    grad.addColorStop(1, '#59001b'); // deep 3D shadow rim
    ctx.fillStyle = grad;
    ctx.shadowColor = 'rgba(255, 0, 84, 0.45)';
    ctx.shadowBlur = 12;
    ctx.fill();

    // 4. Sparkling Glitter Powder & Star Flecks
    const sparkles = [
      { ox: -size * 0.22, oy: -size * 0.08, r: 0.22 },
      { ox: size * 0.24, oy: -size * 0.02, r: 0.18 },
      { ox: -size * 0.06, oy: size * 0.22, r: 0.16 },
      { ox: size * 0.08, oy: -size * 0.24, r: 0.2 }
    ];

    for (let s = 0; s < sparkles.length; s++) {
      const sp = sparkles[s];
      const tw = (Math.sin(sparklePhase + s * 1.6) + 1) * 0.5;
      if (tw > 0.15) {
        ctx.save();
        ctx.translate(sp.ox, sp.oy);
        ctx.fillStyle = s % 2 === 0 ? '#ffd700' : '#ffffff';
        ctx.shadowColor = '#ffd700';
        ctx.shadowBlur = 6;
        const sr = size * sp.r * (0.6 + tw * 0.5);

        // 4-pointed diamond sparkle star
        ctx.beginPath();
        ctx.moveTo(0, -sr);
        ctx.quadraticCurveTo(0, 0, sr, 0);
        ctx.quadraticCurveTo(0, 0, 0, sr);
        ctx.quadraticCurveTo(0, 0, -sr, 0);
        ctx.quadraticCurveTo(0, 0, 0, -sr);
        ctx.fill();

        // Central diamond speck
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(0, 0, sr * 0.25, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    ctx.restore();
  }

  function getBalloonOpenAreaX(side, canvasWidth) {
    const isMobile = canvasWidth < 768;
    // Left open area: left margin to ~22%
    // Right open area: ~78% to right margin
    const leftMarginMin = 18;
    const leftMarginMax = canvasWidth * (isMobile ? 0.22 : 0.24);
    const rightMarginMin = canvasWidth * (isMobile ? 0.78 : 0.76);
    const rightMarginMax = canvasWidth - 18;

    if (side === 'left') {
      return leftMarginMin + Math.random() * Math.max(30, leftMarginMax - leftMarginMin);
    } else {
      return rightMarginMin + Math.random() * Math.max(30, rightMarginMax - rightMarginMin);
    }
  }

  function initPetals() {
    if (!petalsCanvas) return;
    petalsCanvas.width = window.innerWidth;
    petalsCanvas.height = window.innerHeight;
    heartBalloonsList = [];
    balloonSparkleDust = [];

    // Pure Romantic Pink & Ruby Red Palette for Heart Balloons
    const heartColors = ['#ff0054', '#d90429', '#ff4d6d', '#ff0a54', '#ff758c', '#e60067'];
    const totalBalloons = 26;

    for (let i = 0; i < totalBalloons; i++) {
      const side = (i % 2 === 0) ? 'left' : 'right';
      const x = getBalloonOpenAreaX(side, petalsCanvas.width);
      // Evenly distribute vertically from below bottom to top so balloons are already rising gracefully
      const y = (i / totalBalloons) * (petalsCanvas.height + 120);

      heartBalloonsList.push({
        side: side,
        x: x,
        y: y,
        size: 24 + Math.random() * 20,
        speedY: 1.1 + Math.random() * 1.4, // Upward rising speed
        swayAngle: Math.random() * Math.PI * 2,
        swaySpeed: 0.016 + Math.random() * 0.016,
        swayAmp: 0.5 + Math.random() * 0.5,
        rotation: 0,
        color: heartColors[i % heartColors.length],
        sparklePhase: Math.random() * Math.PI * 2
      });
    }

    // Micro glitter sparkle dust floating with the rising balloons
    for (let d = 0; d < 36; d++) {
      const side = (d % 2 === 0) ? 'left' : 'right';
      balloonSparkleDust.push({
        side: side,
        x: getBalloonOpenAreaX(side, petalsCanvas.width),
        y: Math.random() * petalsCanvas.height,
        size: 1.5 + Math.random() * 2.5,
        speedY: 0.8 + Math.random() * 1.2,
        twinkleSpeed: 0.04 + Math.random() * 0.05,
        phase: Math.random() * Math.PI * 2,
        color: d % 2 === 0 ? '#ffd700' : '#ffffff'
      });
    }
  }

  function drawPetals() {
    if (!petalsCanvas || !petalsEnabled) return;
    const ctx = petalsCanvas.getContext('2d');
    const cw = petalsCanvas.width;
    const ch = petalsCanvas.height;
    ctx.clearRect(0, 0, cw, ch);

    const isMobile = cw < 768;
    const leftLimit = cw * (isMobile ? 0.23 : 0.25);
    const rightLimit = cw * (isMobile ? 0.77 : 0.75);

    // 1. Draw rising micro-glitter dust in left & right open areas
    for (let d = 0; d < balloonSparkleDust.length; d++) {
      const dust = balloonSparkleDust[d];
      dust.y -= dust.speedY;
      dust.phase += dust.twinkleSpeed;
      if (dust.y < -20) {
        dust.y = ch + 20;
        dust.side = Math.random() < 0.5 ? 'left' : 'right';
        dust.x = getBalloonOpenAreaX(dust.side, cw);
      }
      const alpha = 0.35 + Math.sin(dust.phase) * 0.45;
      if (alpha > 0.05) {
        ctx.fillStyle = dust.color;
        ctx.globalAlpha = Math.min(1, Math.max(0, alpha));
        ctx.beginPath();
        ctx.arc(dust.x, dust.y, dust.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1.0;
      }
    }

    // 2. Draw rising Heart Balloons with Glitter
    for (let i = 0; i < heartBalloonsList.length; i++) {
      const b = heartBalloonsList[i];
      // Float upward towards the sky
      b.y -= b.speedY;

      // Natural gentle horizontal sway
      b.swayAngle += b.swaySpeed;
      b.x += Math.sin(b.swayAngle) * b.swayAmp;

      // Restrict strictly to open area (left or right) so center stays completely clear
      if (b.side === 'left') {
        b.x = Math.max(14, Math.min(leftLimit, b.x));
      } else {
        b.x = Math.max(rightLimit, Math.min(cw - 14, b.x));
      }

      // Buoyant tilt
      b.rotation = Math.sin(b.swayAngle * 0.8) * 0.12;
      b.sparklePhase += 0.06;

      // When balloon floats above the screen top, recycle it from the bottom
      if (b.y < -90) {
        b.y = ch + 50 + Math.random() * 80;
        b.side = Math.random() < 0.5 ? 'left' : 'right';
        b.x = getBalloonOpenAreaX(b.side, cw);
        b.speedY = 1.1 + Math.random() * 1.4;
      }

      drawHeartBalloon(ctx, b.x, b.y, b.size, b.color, b.rotation, b.sparklePhase);
    }

    requestAnimationFrame(drawPetals);
  }

  initPetals();
  requestAnimationFrame(drawPetals);

  window.addEventListener('resize', () => {
    if (petalsCanvas) {
      petalsCanvas.width = window.innerWidth;
      petalsCanvas.height = window.innerHeight;
    }
  });

  if (quickPetalsBtn) {
    quickPetalsBtn.addEventListener('click', () => {
      petalsEnabled = !petalsEnabled;
      if (petalsCanvas) {
        if (petalsEnabled) {
          petalsCanvas.classList.remove('disabled');
          quickPetalsBtn.classList.add('active');
          requestAnimationFrame(drawPetals);
        } else {
          petalsCanvas.classList.add('disabled');
          quickPetalsBtn.classList.remove('active');
        }
      }
    });
  }

  /* =========================================================
     MENU DRAWER CONTROLS (3-LINE HAMBURGER)
     ========================================================= */
  function openMenuDrawer() {
    menuDrawer.classList.add('open');
    menuDrawerBackdrop.classList.add('show');
  }

  function closeMenuDrawer() {
    menuDrawer.classList.remove('open');
    menuDrawerBackdrop.classList.remove('show');
  }

  mainMenuBtn.addEventListener('click', openMenuDrawer);
  closeMenuBtn.addEventListener('click', closeMenuDrawer);
  menuDrawerBackdrop.addEventListener('click', closeMenuDrawer);

  // Romantic Intermediate Chat Elements
  const romanticChatScreen = document.getElementById('romantic-chat-screen');
  const chatFloatingHearts = document.getElementById('chat-floating-hearts');
  const chatLiveStatus = document.getElementById('chat-live-status');
  const chatStepCounter = document.getElementById('chat-step-counter');
  const btnSkipChat = document.getElementById('btn-skip-chat');
  const chatMessagesScroll = document.getElementById('chat-messages-scroll');
  const chatTypingIndicator = document.getElementById('chat-typing-indicator');
  const chatQuickReplies = document.getElementById('chat-quick-replies');
  const chatUserInput = document.getElementById('chat-user-input');
  const chatEmojiHeartBtn = document.getElementById('chat-emoji-heart-btn');
  const chatSendBtn = document.getElementById('chat-send-btn');
  const chatFooterActions = document.getElementById('chat-footer-actions');
  const btnGoToOrder = document.getElementById('btn-go-to-order');
  const btnEnter3DWorld = document.getElementById('btn-enter-3d-world');

  // WhatsApp-Style Quote Bar Elements
  const chatQuoteBarContainer = document.getElementById('chat-quote-bar-container');
  const quoteChapterTitle = document.getElementById('quote-chapter-title');
  const quoteChapterDesc = document.getElementById('quote-chapter-desc');
  const btnCancelQuote = document.getElementById('btn-cancel-quote');
  const btnResumeQuestions = document.getElementById('btn-resume-questions');

  // 2-Way Live Follow-up Chat & Quote State
  let activeFollowUpQuote = null; // { chapterNum, heading, snippet }
  let isAutomatedChatPaused = false; // Set to true when she follows up on a chapter
  let liveChatBus = null;
  let surpriseCreatorUsername = null; // Username of creator when viewing short link ?s=
  let activeSurpriseToken = null; // Active surprise token when viewing short link ?s=
  try {
    liveChatBus = new BroadcastChannel('birthday_live_bus');
  } catch(e) {}

  // Robust User Key Resolver for live progress & 2-way chat
  function getRecipientUserKey() {
    const params = new URLSearchParams(window.location.search || window.location.hash.replace(/^#/, '?'));
    if (params.has('u') && params.get('u').trim()) {
      return params.get('u').trim().toLowerCase();
    }
    if (surpriseCreatorUsername) {
      return surpriseCreatorUsername.trim().toLowerCase();
    }
    if (currentPortalUser) {
      return currentPortalUser.trim().toLowerCase();
    }
    try {
      const session = localStorage.getItem('birthday_portal_session');
      if (session) return session.trim().toLowerCase();
    } catch(e) {}
    return 'user';
  }

  // Recipient Activity Tracking Helper
  function trackRecipientActivity(action, details, icon = '✨') {
    const username = getRecipientUserKey();
    const token = activeSurpriseToken || (new URLSearchParams(window.location.search || window.location.hash.replace(/^#/, '?')).get('s') || '').trim();
    const now = new Date();
    const timeStr = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;
    const actData = { action, details, icon, time: timeStr, username, token };

    if (liveChatBus) {
      try { liveChatBus.postMessage({ type: 'activity', data: actData }); } catch(e) {}
    }

    fetch(`${API_BASE}/api/track_activity`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(actData)
    }).catch(() => {});
  }

  // Resume System Automated Questions
  function resumeSystemQuestions() {
    isAutomatedChatPaused = false;
    activeFollowUpQuote = null;
    if (chatQuoteBarContainer) chatQuoteBarContainer.classList.add('hidden');
    if (btnResumeQuestions) btnResumeQuestions.classList.add('hidden');
    if (chatLiveStatus) chatLiveStatus.textContent = "Typing with love...";
    if (chatUserInput) {
      chatUserInput.disabled = true;
      chatUserInput.value = '';
      chatUserInput.placeholder = "Boyfriend is typing a question...";
    }
    if (chatSendBtn) chatSendBtn.disabled = true;
    if (chatQuickReplies) chatQuickReplies.innerHTML = '';
    typeNextQuestion();
  }

  // Continue / Resume Questions Button Handler
  if (btnResumeQuestions) {
    btnResumeQuestions.addEventListener('click', (e) => {
      e.preventDefault();
      resumeSystemQuestions();
    });
  }

  // Cancel Quote Button Handler
  if (btnCancelQuote) {
    btnCancelQuote.addEventListener('click', () => {
      resumeSystemQuestions();
    });
  }

  // 5 Romantic Questions from Boyfriend to Girlfriend
  const romanticQuestions = [
    {
      question: "Hey prettiest girl... 💕 Do you know who is the luckiest guy in the entire universe today? (Hint: The one typing this for you ❤️)",
      suggestions: ["You are! 🥰", "My handsome boy ❤️", "Aww so sweet! 💕"]
    },
    {
      question: "What is the one thing that made you smile the most this past year? 🥰",
      suggestions: ["Being with you! ❤️", "All our cute calls 📱", "Your sweet surprises 🎁"]
    },
    {
      question: "If you could make one magical birthday wish right this second, what would it be? ✨",
      suggestions: ["To stay by your side forever 💕", "Lots of happiness & love 🌸", "A big tight hug right now! 🫂"]
    },
    {
      question: "What is your absolute favorite memory of us together so far? 💕",
      suggestions: ["Every moment with you 🥰", "Our late night talks 🌙", "Our first date 🌹"]
    },
    {
      question: "Are you ready to step into your grand 3D birthday surprise wonderland now, my princess? 👑🎂",
      suggestions: ["Yes, take me there! ✨", "Can't wait! 🎉", "Let's celebrate! 💖"]
    }
  ];

  let activeChatQuestions = [...romanticQuestions];
  let currentQuestionIndex = 0;
  let isTypingQuestion = false;

  /* =========================================================
     FLOATING HEARTS GENERATOR FOR CHAT SCREEN
     ========================================================= */
  function initFloatingChatHearts() {
    if (!chatFloatingHearts) return;
    chatFloatingHearts.innerHTML = '';
    const heartEmojis = ['💖', '💕', '💗', '💓', '✨', '🌹'];
    for (let i = 0; i < 15; i++) {
      const heart = document.createElement('div');
      heart.className = 'floating-heart-item';
      heart.textContent = heartEmojis[Math.floor(Math.random() * heartEmojis.length)];
      heart.style.left = `${Math.random() * 95}%`;
      heart.style.animationDuration = `${5 + Math.random() * 6}s`;
      heart.style.animationDelay = `${Math.random() * 5}s`;
      heart.style.fontSize = `${1.2 + Math.random() * 1.2}rem`;
      chatFloatingHearts.appendChild(heart);
    }
  }

  /* =========================================================
     STEP 1: INTRO CURTAIN OPEN -> STEP 2: ROMANTIC LIVE CHAT
     ========================================================= */
  if (btnStartCelebration) {
    btnStartCelebration.addEventListener('click', (e) => {
      e.preventDefault();
      // Open royal curtains
      if (curtainContainer) {
        curtainContainer.classList.add('opened');
      }

      // Remove early route shield & curtain route class so intermediate romantic screen can show
      document.documentElement.classList.remove('route-surprise-curtain');
      const earlyShield = document.getElementById('early-route-shield');
      if (earlyShield) {
        try { earlyShield.remove(); } catch(e) {}
      }
      
      // Track activity
      trackRecipientActivity('curtains_opened', `Opened Royal Velvet Curtains & Started Celebration 💖`, '👑');

      // Play sound & initial confetti
      if (window.birthdayAudio) {
        try {
          window.birthdayAudio.init();
          window.birthdayAudio.playGiftOpen();
        } catch(err) {}
      }
      if (window.confetti) {
        try {
          window.confetti({ particleCount: 50, spread: 80, origin: { y: 0.5 } });
        } catch(err) {}
      }

      // Reveal Romantic Intermediate Chat Screen (with Memories Album, Safarnama Diary & Live Chat)
      if (romanticChatScreen) {
        setTimeout(() => {
          romanticChatScreen.classList.remove('hidden');
          romanticChatScreen.style.display = 'flex';
          initFloatingChatHearts();
          startRomanticChatJourney();
        }, 400);
      } else {
        transitionFromChatTo3D();
      }
    });
  }

  /* =========================================================
     STEP 2 CONTROLLER: LIVE CHAT TYPEWRITER JOURNEY
     ========================================================= */
  function startRomanticChatJourney() {
    currentQuestionIndex = 0;
    // Clear previous messages except typing indicator
    if (chatMessagesScroll) {
      const rows = chatMessagesScroll.querySelectorAll('.chat-msg-row');
      rows.forEach(r => r.remove());
    }
    if (chatFooterActions) chatFooterActions.classList.add('hidden');
    
    // Start typing Question 1 after a gentle delay
    setTimeout(() => {
      typeNextQuestion();
    }, 600);
  }

  function typeNextQuestion() {
    // If automated questioning is paused because she's having a 2-way follow-up conversation, halt!
    if (isAutomatedChatPaused) return;

    if (currentQuestionIndex >= activeChatQuestions.length) {
      finishChatJourney();
      return;
    }

    isTypingQuestion = true;
    const rawQ = activeChatQuestions[currentQuestionIndex];
    const qData = typeof rawQ === 'string'
      ? { question: rawQ, suggestions: ["Aww so sweet! 💕", "Thank you! ❤️", "Love this! ✨"] }
      : rawQ;
    if (chatStepCounter) chatStepCounter.textContent = currentQuestionIndex + 1;
    if (chatLiveStatus) chatLiveStatus.textContent = "Typing with love...";

    // Disable input while boyfriend is typing
    if (chatUserInput) {
      chatUserInput.disabled = true;
      chatUserInput.value = '';
      chatUserInput.placeholder = "Boyfriend is typing a question...";
    }
    if (chatSendBtn) chatSendBtn.disabled = true;
    if (chatQuickReplies) chatQuickReplies.innerHTML = '';

    // Show 3-dot typing indicator
    if (chatTypingIndicator) {
      chatTypingIndicator.classList.remove('hidden');
      chatMessagesScroll.appendChild(chatTypingIndicator);
      scrollChatToBottom();
    }

    // Simulate typing delay before stream starts
    setTimeout(() => {
      if (chatTypingIndicator) chatTypingIndicator.classList.add('hidden');

      // Create boyfriend message bubble container
      const msgRow = document.createElement('div');
      msgRow.className = 'chat-msg-row boyfriend-row';

      const avatar = document.createElement('div');
      avatar.className = 'chat-bubble-avatar';
      avatar.textContent = '👦';

      const bubble = document.createElement('div');
      bubble.className = 'chat-msg-bubble boyfriend-bubble';

      const textSpan = document.createElement('span');
      textSpan.className = 'chat-bubble-text';

      const cursor = document.createElement('span');
      cursor.className = 'chat-live-cursor';

      bubble.appendChild(textSpan);
      bubble.appendChild(cursor);
      msgRow.appendChild(avatar);
      msgRow.appendChild(bubble);

      chatMessagesScroll.appendChild(msgRow);
      scrollChatToBottom();

      // Stream text letter-by-letter / word-by-word
      const textToType = qData.question;
      let charIdx = 0;

      const typeInterval = setInterval(() => {
        if (charIdx < textToType.length) {
          textSpan.textContent += textToType[charIdx];
          charIdx++;
          scrollChatToBottom();
        } else {
          clearInterval(typeInterval);
          cursor.remove();
          
          // Add timestamp
          const timeSpan = document.createElement('div');
          timeSpan.className = 'chat-bubble-time';
          const now = new Date();
          timeSpan.textContent = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;
          bubble.appendChild(timeSpan);

          isTypingQuestion = false;
          if (chatLiveStatus) chatLiveStatus.textContent = "Online • Waiting for your reply 💕";

          // Enable user input & populate suggestions
          enableUserReplyInput(qData.suggestions);
        }
      }, 32);

    }, 850);
  }

  function enableUserReplyInput(suggestions = []) {
    if (chatUserInput) {
      chatUserInput.disabled = false;
      chatUserInput.placeholder = "Please enter your reply...";
      chatUserInput.focus();
    }

    // Populate quick response pills
    if (chatQuickReplies) {
      chatQuickReplies.innerHTML = '';
      suggestions.forEach(text => {
        const pill = document.createElement('button');
        pill.type = 'button';
        pill.className = 'quick-reply-pill';
        pill.innerHTML = `<span>${text}</span>`;
        pill.addEventListener('click', () => {
          sendGirlfriendReply(text);
        });
        chatQuickReplies.appendChild(pill);
      });
    }

    if (chatSendBtn) chatSendBtn.disabled = !chatUserInput.value.trim();
  }

  // Chat History Modal & Corner Button Elements
  const floatingChatHistoryBtn = document.getElementById('floating-chat-history-btn');
  const btnDrawerChatHistory = document.getElementById('btn-drawer-chat-history');
  const chatHistoryModal = document.getElementById('chat-history-modal');
  const closeChatHistoryModal = document.getElementById('close-chat-history-modal');
  const chatHistoryContent = document.getElementById('chat-history-content');
  const chatHistoryBadgeCount = document.getElementById('chat-history-badge-count');
  const btnCopyChatHistory = document.getElementById('btn-copy-chat-history');
  const btnClearChatHistory = document.getElementById('btn-clear-chat-history');
  const historyCopyFeedback = document.getElementById('history-copy-feedback');

  function getSavedChatHistory() {
    try {
      const data = localStorage.getItem('birthday_chat_history');
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  function saveChatMessageToHistory(entry) {
    try {
      const history = getSavedChatHistory();
      history.push(entry);
      localStorage.setItem('birthday_chat_history', JSON.stringify(history));
      updateChatHistoryBadge();
    } catch (e) {
      console.warn('Could not save chat history to localStorage', e);
    }
  }

  function updateChatHistoryBadge() {
    const history = getSavedChatHistory();
    if (chatHistoryBadgeCount) {
      if (history.length > 0) {
        chatHistoryBadgeCount.textContent = history.length;
        chatHistoryBadgeCount.classList.remove('hidden');
      } else {
        chatHistoryBadgeCount.classList.add('hidden');
      }
    }
  }

  function openChatHistoryModalView() {
    renderChatHistoryUI();
    if (chatHistoryModal) {
      chatHistoryModal.classList.add('show');
    }
  }

  function renderChatHistoryUI() {
    if (!chatHistoryContent) return;
    const history = getSavedChatHistory();

    if (history.length === 0) {
      chatHistoryContent.innerHTML = `
        <div class="chat-history-empty">
          <div style="font-size: 2.2rem; margin-bottom: 8px;">💌</div>
          <div><strong>No chat answers recorded yet!</strong></div>
          <div style="font-size: 0.85rem; margin-top: 4px; opacity: 0.8;">Once she answers the sweet questions during the birthday chat, her responses will be automatically saved here for you! 💕</div>
        </div>
      `;
      return;
    }

    let html = '';
    history.forEach((item, idx) => {
      html += `
        <div class="chat-history-item">
          <div class="history-q-box">
            <span class="history-q-icon">👦</span>
            <div><strong>Q${idx + 1}:</strong> ${item.question || ''}</div>
          </div>
          <div class="history-a-box">
            <span class="history-a-icon">👸</span>
            <div><strong>Her Answer:</strong> "${item.reply || ''}"</div>
          </div>
          <div class="history-timestamp">
            <i class="fa-regular fa-clock"></i> ${item.time || ''} ${item.date ? '• ' + item.date : ''}
          </div>
        </div>
      `;
    });

    chatHistoryContent.innerHTML = html;
  }

  if (floatingChatHistoryBtn) {
    floatingChatHistoryBtn.addEventListener('click', openChatHistoryModalView);
  }

  if (btnDrawerChatHistory) {
    btnDrawerChatHistory.addEventListener('click', () => {
      closeMenuDrawer();
      openChatHistoryModalView();
    });
  }

  if (closeChatHistoryModal) {
    closeChatHistoryModal.addEventListener('click', () => {
      chatHistoryModal.classList.remove('show');
    });
  }

  if (btnCopyChatHistory) {
    btnCopyChatHistory.addEventListener('click', () => {
      const history = getSavedChatHistory();
      if (history.length === 0) {
        alert("No answers to copy yet! 💕");
        return;
      }
      let copyText = `💖 HER SWEET BIRTHDAY CHAT ANSWERS 💖\n`;
      copyText += `Celebrant: ${celebrantName}\n\n`;
      history.forEach((item, idx) => {
        copyText += `Question ${idx + 1}: ${item.question}\n`;
        copyText += `Her Reply: "${item.reply}" (${item.time || ''})\n\n`;
      });

      try {
        navigator.clipboard.writeText(copyText).then(() => {
          if (historyCopyFeedback) {
            historyCopyFeedback.classList.add('show');
            setTimeout(() => historyCopyFeedback.classList.remove('show'), 3000);
          }
        }).catch(() => {
          alert("Answers copied!\n\n" + copyText);
        });
      } catch(err) {
        alert("Answers copied!\n\n" + copyText);
      }
    });
  }

  if (btnClearChatHistory) {
    btnClearChatHistory.addEventListener('click', () => {
      if (confirm("Are you sure you want to clear saved chat history?")) {
        try {
          localStorage.removeItem('birthday_chat_history');
          updateChatHistoryBadge();
          renderChatHistoryUI();
        } catch(e) {}
      }
    });
  }

  updateChatHistoryBadge();

  function syncAnswerToTelegram(data) {
    // 1. Send to local Telegram bot API server
    try {
      fetch(`${API_BASE}/api/notify_answer`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      }).catch(() => {});
    } catch(e) {}

    // Telegram notification is handled server-side via /api/notify_answer
  }

  function sendGirlfriendReply(replyText) {
    const text = replyText || (chatUserInput ? chatUserInput.value.trim() : '');
    if (!text || isTypingQuestion) return;

    const rawQ = activeChatQuestions[currentQuestionIndex];
    const currentQData = typeof rawQ === 'string' ? { question: rawQ, suggestions: [] } : (rawQ || { question: "Lovely Question", suggestions: [] });
    const now = new Date();
    const timeStr = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;
    const quotedData = activeFollowUpQuote ? { ...activeFollowUpQuote } : null;

    // Reset quote bar if active
    if (activeFollowUpQuote) {
      activeFollowUpQuote = null;
      if (chatQuoteBarContainer) chatQuoteBarContainer.classList.add('hidden');
    }

    // Create girlfriend message bubble (with optional WhatsApp-style quote banner inside)
    const msgRow = document.createElement('div');
    msgRow.className = 'chat-msg-row girlfriend-row';

    const bubble = document.createElement('div');
    bubble.className = 'chat-msg-bubble girlfriend-bubble';

    if (quotedData) {
      const quoteBox = document.createElement('div');
      quoteBox.className = 'msg-quote-preview-bubble';
      quoteBox.innerHTML = `
        <div class="quote-mini-title"><i class="fa-solid fa-feather-pointed"></i> Chapter ${quotedData.chapterNum || ''}: ${quotedData.heading || ''}</div>
        <div class="quote-mini-desc">"${(quotedData.snippet || '').substring(0, 75)}..."</div>
      `;
      bubble.appendChild(quoteBox);
    }

    const textSpan = document.createElement('span');
    textSpan.className = 'chat-bubble-text';
    textSpan.textContent = text;

    const timeSpan = document.createElement('div');
    timeSpan.className = 'chat-bubble-time';
    timeSpan.textContent = timeStr;

    bubble.appendChild(textSpan);
    bubble.appendChild(timeSpan);

    const avatar = document.createElement('div');
    avatar.className = 'chat-bubble-avatar';
    avatar.textContent = '👸';

    msgRow.appendChild(bubble);
    msgRow.appendChild(avatar);

    chatMessagesScroll.appendChild(msgRow);
    scrollChatToBottom();

    // If she is in follow-up / 2-way live chat mode:
    if (isAutomatedChatPaused || quotedData) {
      isAutomatedChatPaused = true;
      if (btnResumeQuestions) btnResumeQuestions.classList.remove('hidden');

      // Reset input for next custom live message
      if (chatUserInput) {
        chatUserInput.value = '';
        chatUserInput.disabled = false;
        chatUserInput.placeholder = "Type your message to him...";
        chatUserInput.focus();
      }
      if (chatSendBtn) chatSendBtn.disabled = true;
      if (chatQuickReplies) chatQuickReplies.innerHTML = '';
      if (chatLiveStatus) chatLiveStatus.textContent = "Live Chat Connected 💕";

      // Dispatch 2-way live chat message to backend server
      const username = getRecipientUserKey();
      const token = activeSurpriseToken || (new URLSearchParams(window.location.search || window.location.hash.replace(/^#/, '?')).get('s') || '').trim();
      const livePayload = {
        username: username,
        token: token,
        sender: 'celebrant',
        text: text,
        quote: quotedData,
        time: timeStr
      };

      fetch(`${API_BASE}/api/live_chat_send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(livePayload)
      }).catch(() => {});

      if (liveChatBus) {
        try {
          liveChatBus.postMessage({ type: 'live_chat_msg', data: livePayload });
        } catch(e) {}
      }

      // Track activity
      trackRecipientActivity('live_chat_msg', `Girlfriend sent: "${text.substring(0, 35)}..."`, '💬');

      // Play sweet chime
      try {
        if (window.birthdayAudio) {
          window.birthdayAudio.init();
          if (typeof window.birthdayAudio.playChimeTone === 'function' && window.birthdayAudio.ctx) {
            window.birthdayAudio.playChimeTone(659.25, window.birthdayAudio.ctx.currentTime, 0.35, 0.3);
          }
        }
      } catch(e) {}

      if (window.confetti) {
        window.confetti({ particleCount: 25, spread: 55, origin: { y: 0.7 } });
      }

      // Do NOT auto-advance romanticQuestions while in 2-way follow-up conversation!
      return;
    }

    // Default automated questionnaire flow
    if (chatUserInput) {
      chatUserInput.value = '';
      chatUserInput.disabled = true;
      chatUserInput.placeholder = "Sending love... 💕";
    }
    if (chatSendBtn) chatSendBtn.disabled = true;
    if (chatQuickReplies) chatQuickReplies.innerHTML = '';

    // Save answer into persistent local storage for boyfriend to view anytime
    const answerData = {
      index: currentQuestionIndex + 1,
      questionNumber: currentQuestionIndex + 1,
      question: currentQData ? currentQData.question : `Question ${currentQuestionIndex + 1}`,
      reply: text,
      celebrant: celebrantName || 'Girlfriend',
      username: getRecipientUserKey(),
      token: activeSurpriseToken || '',
      time: timeStr,
      date: now.toLocaleDateString()
    };
    saveChatMessageToHistory(answerData);

    // Sync in real-time to Telegram Bot API
    syncAnswerToTelegram(answerData);

    // Play sweet chime safely
    try {
      if (window.birthdayAudio) {
        window.birthdayAudio.init();
        if (typeof window.birthdayAudio.playChimeTone === 'function' && window.birthdayAudio.ctx) {
          window.birthdayAudio.playChimeTone(659.25, window.birthdayAudio.ctx.currentTime, 0.35, 0.3);
        }
      }
    } catch(err) {
      console.log('Audio notice:', err);
    }

    // Mini confetti on reply
    if (window.confetti) {
      window.confetti({ particleCount: 25, spread: 55, origin: { y: 0.7 } });
    }

    // Move to next question smoothly
    currentQuestionIndex++;
    if (currentQuestionIndex < activeChatQuestions.length) {
      setTimeout(() => {
        typeNextQuestion();
      }, 700);
    } else {
      setTimeout(() => {
        finishChatJourney();
      }, 900);
    }
  }

  // Receive Creator's Live Replies in Girlfriend's Chat Screen via BroadcastChannel & Polling
  function receiveCreatorLiveMessage(msgData) {
    if (!msgData || msgData.sender !== 'creator') return;

    const msgRow = document.createElement('div');
    msgRow.className = 'chat-msg-row boyfriend-row live-incoming';

    const avatar = document.createElement('div');
    avatar.className = 'chat-bubble-avatar';
    avatar.textContent = '👦';

    const bubble = document.createElement('div');
    bubble.className = 'chat-msg-bubble boyfriend-bubble';

    const textSpan = document.createElement('span');
    textSpan.className = 'chat-bubble-text';
    textSpan.textContent = msgData.text;

    const timeSpan = document.createElement('div');
    timeSpan.className = 'chat-bubble-time';
    timeSpan.textContent = msgData.time || `${new Date().getHours()}:${String(new Date().getMinutes()).padStart(2, '0')}`;

    bubble.appendChild(textSpan);
    bubble.appendChild(timeSpan);

    msgRow.appendChild(avatar);
    msgRow.appendChild(bubble);

    if (chatMessagesScroll) {
      chatMessagesScroll.appendChild(msgRow);
      scrollChatToBottom();
    }

    if (chatLiveStatus) {
      chatLiveStatus.textContent = "Boyfriend replied 💕";
    }

    // Play chime tone
    try {
      if (window.birthdayAudio) {
        window.birthdayAudio.init();
        if (typeof window.birthdayAudio.playChimeTone === 'function' && window.birthdayAudio.ctx) {
          window.birthdayAudio.playChimeTone(523.25, window.birthdayAudio.ctx.currentTime, 0.4, 0.35);
        }
      }
    } catch(e) {}
  }

  const celebrantSeenMsgIds = new Set();

  if (liveChatBus) {
    liveChatBus.onmessage = (event) => {
      const { type, data } = event.data || {};
      if (type === 'live_chat_msg' && data && data.sender === 'creator') {
        const msgKey = data.id || (data.text + '_' + (data.timestamp || data.time));
        if (!celebrantSeenMsgIds.has(msgKey)) {
          celebrantSeenMsgIds.add(msgKey);
          receiveCreatorLiveMessage(data);
        }
      }
    };
  }

  // Cross-device live reply polling for Celebrant (phone & computer across internet)
  async function celebrantPollLiveReplies() {
    const username = getRecipientUserKey();
    const token = activeSurpriseToken || (new URLSearchParams(window.location.search || window.location.hash.replace(/^#/, '?')).get('s') || '').trim();
    if (!token && (!username || username === 'user')) return;

    try {
      const url = `${API_BASE}/api/live_progress?username=${encodeURIComponent(username)}${token ? `&token=${encodeURIComponent(token)}` : ''}`;
      const res = await fetch(url);
      if (!res.ok) return;
      const json = await res.json();
      if (json && json.status === 'success' && json.chat && Array.isArray(json.chat.messages)) {
        json.chat.messages.forEach(msg => {
          if (msg.sender === 'creator') {
            const msgKey = msg.id || (msg.text + '_' + (msg.timestamp || msg.time));
            if (!celebrantSeenMsgIds.has(msgKey)) {
              celebrantSeenMsgIds.add(msgKey);
              receiveCreatorLiveMessage(msg);
            }
          } else if (msg.id) {
            celebrantSeenMsgIds.add(msg.id);
          }
        });
      }
    } catch(e) {}
  }
  setInterval(celebrantPollLiveReplies, 3000);

  function finishChatJourney() {
    if (chatLiveStatus) chatLiveStatus.textContent = "So in love with you! 💖";
    if (chatUserInput) {
      chatUserInput.disabled = true;
      chatUserInput.placeholder = "All 5 questions answered with love! 💕";
    }
    if (chatSendBtn) chatSendBtn.disabled = true;
    if (chatQuickReplies) chatQuickReplies.innerHTML = '';

    // Show sweet concluding boyfriend message
    const msgRow = document.createElement('div');
    msgRow.className = 'chat-msg-row boyfriend-row';

    const avatar = document.createElement('div');
    avatar.className = 'chat-bubble-avatar';
    avatar.textContent = '👦';

    const bubble = document.createElement('div');
    bubble.className = 'chat-msg-bubble boyfriend-bubble';
    bubble.innerHTML = `
      <div style="font-size: 1.05rem; font-weight: 700; color: #ffccd5; margin-bottom: 4px;">Aww, you have my whole heart! 💖</div>
      <div>Happy Birthday to the love of my life! Every second with you is a blessing. All your sweet answers are saved in our Chat History! Now let's enter your grand 3D birthday surprise wonderland! 🎉🎂✨</div>
      <div class="chat-bubble-time">${new Date().getHours()}:${String(new Date().getMinutes()).padStart(2, '0')}</div>
    `;

    msgRow.appendChild(avatar);
    msgRow.appendChild(bubble);
    chatMessagesScroll.appendChild(msgRow);
    scrollChatToBottom();

    // Big celebration fanfare
    if (window.confetti) {
      window.confetti({ particleCount: 100, spread: 90, origin: { y: 0.55 } });
    }
    try {
      if (window.birthdayAudio) {
        window.birthdayAudio.init();
        if (typeof window.birthdayAudio.playGiftOpen === 'function') {
          window.birthdayAudio.playGiftOpen();
        }
      }
    } catch(err) {}

    // Reveal Action Buttons: "Go to Order" and "Enter 3D Birthday World"
    if (chatFooterActions) {
      chatFooterActions.classList.remove('hidden');
    }
  }

  function scrollChatToBottom() {
    if (chatMessagesScroll) {
      chatMessagesScroll.scrollTop = chatMessagesScroll.scrollHeight;
    }
  }

  // Input events
  if (chatUserInput) {
    chatUserInput.addEventListener('input', () => {
      if (chatSendBtn) {
        chatSendBtn.disabled = !chatUserInput.value.trim();
      }
    });

    chatUserInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendGirlfriendReply();
      }
    });
  }

  if (chatEmojiHeartBtn) {
    chatEmojiHeartBtn.addEventListener('click', () => {
      if (chatUserInput && !chatUserInput.disabled) {
        chatUserInput.value += '💖';
        chatUserInput.focus();
        if (chatSendBtn) chatSendBtn.disabled = false;
      }
    });
  }

  if (chatSendBtn) {
    chatSendBtn.addEventListener('click', () => sendGirlfriendReply());
  }

  // "Go to Order" Full Screen Page Elements
  const orderHubFullscreenPage = document.getElementById('order-hub-fullscreen-page');
  const btnOrderBackToStory = document.getElementById('btn-order-back-to-story');
  const btnOrderFooterBack = document.getElementById('btn-order-footer-back');
  const btnOrderNavEnter3D = document.getElementById('btn-order-nav-enter-3d');
  const btnOrderFooter3D = document.getElementById('btn-order-footer-3d');
  const btnDrawerOrderHub = document.getElementById('btn-drawer-order-hub');
  const orderFilterPills = document.querySelectorAll('.order-filter-pill');
  const orderUpiBanner = document.getElementById('order-upi-banner');
  const orderUpiDisplay = document.getElementById('order-upi-display');
  const btnCopyUpi = document.getElementById('btn-copy-upi');
  const copyUpiStatusText = document.getElementById('copy-upi-status-text');
  let creatorUpiId = '';

  function updateUpiOrderDisplay(upi) {
    const cleanUpi = (upi || '').trim();
    creatorUpiId = cleanUpi;
    if (orderUpiDisplay) {
      orderUpiDisplay.textContent = cleanUpi || 'yourlove@upi';
    }
    const creatorInputUpiEl = document.getElementById('creator-input-upi');
    const inputUpiEl = document.getElementById('input-upi');
    if (creatorInputUpiEl && cleanUpi) creatorInputUpiEl.value = cleanUpi;
    if (inputUpiEl && cleanUpi) inputUpiEl.value = cleanUpi;
  }

  let orderOpenedFromChat = false;
  function openFullScreenOrderHub(fromChat = false) {
    orderOpenedFromChat = fromChat;
    if (fromChat && romanticChatScreen) romanticChatScreen.classList.add('hidden');
    if (orderHubFullscreenPage) {
      orderHubFullscreenPage.classList.remove('hidden');
      orderHubFullscreenPage.scrollTop = 0;
      if (window.birthdayAudio) {
        try { window.birthdayAudio.playGiftOpen(); } catch(e) {}
      }
      if (window.confetti) {
        window.confetti({ particleCount: 35, spread: 65, origin: { y: 0.6 } });
      }
    }
  }

  function closeFullScreenOrderHub() {
    if (orderHubFullscreenPage) orderHubFullscreenPage.classList.add('hidden');
    if (orderOpenedFromChat && romanticChatScreen) {
      romanticChatScreen.classList.remove('hidden');
      orderOpenedFromChat = false;
    }
  }

  // Copy UPI to Clipboard with Haptic & Sound Feedback
  if (btnCopyUpi) {
    btnCopyUpi.addEventListener('click', async () => {
      const upiToCopy = (creatorUpiId && creatorUpiId.trim())
        ? creatorUpiId.trim()
        : (orderUpiDisplay ? orderUpiDisplay.textContent.trim() : '');
      if (!upiToCopy) return;

      const triggerCopiedUi = () => {
        btnCopyUpi.classList.add('copied');
        if (copyUpiStatusText) copyUpiStatusText.textContent = 'Copied! ✅';
        if (window.birthdayAudio) {
          try { window.birthdayAudio.playGiftOpen(); } catch(e) {}
        }
        if (navigator.vibrate) {
          try { navigator.vibrate(60); } catch(e) {}
        }
        setTimeout(() => {
          btnCopyUpi.classList.remove('copied');
          if (copyUpiStatusText) copyUpiStatusText.textContent = 'Copy UPI';
        }, 2200);
      };

      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(upiToCopy);
          triggerCopiedUi();
        } else {
          throw new Error('Clipboard API unavailable');
        }
      } catch (err) {
        const tempInput = document.createElement('input');
        tempInput.value = upiToCopy;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        triggerCopiedUi();
      }
    });
  }

  if (btnGoToOrder) {
    btnGoToOrder.addEventListener('click', () => openFullScreenOrderHub(true));
  }

  if (btnDrawerOrderHub) {
    btnDrawerOrderHub.addEventListener('click', () => {
      closeMenuDrawer();
      openFullScreenOrderHub();
    });
  }

  if (btnOrderBackToStory) {
    btnOrderBackToStory.addEventListener('click', closeFullScreenOrderHub);
  }

  if (btnOrderFooterBack) {
    btnOrderFooterBack.addEventListener('click', closeFullScreenOrderHub);
  }

  if (btnOrderNavEnter3D) {
    btnOrderNavEnter3D.addEventListener('click', () => {
      if (orderHubFullscreenPage) orderHubFullscreenPage.classList.add('hidden');
      transitionFromChatTo3D();
    });
  }

  if (btnOrderFooter3D) {
    btnOrderFooter3D.addEventListener('click', () => {
      if (orderHubFullscreenPage) orderHubFullscreenPage.classList.add('hidden');
      transitionFromChatTo3D();
    });
  }

  // Filter Pills for Store Apps (Zomato, Swiggy, Blinkit, Amazon, etc.)
  if (orderFilterPills) {
    orderFilterPills.forEach(pill => {
      pill.addEventListener('click', () => {
        orderFilterPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');

        const filterKey = pill.getAttribute('data-filter');
        const sections = document.querySelectorAll('.store-app-section');

        sections.forEach(sec => {
          const storeKey = sec.getAttribute('data-store');
          if (filterKey === 'all' || filterKey === storeKey) {
            sec.style.display = 'flex';
          } else {
            sec.style.display = 'none';
          }
        });
      });
    });
  }

  // "Enter 3D Birthday World" and "Skip to 3D" buttons
  function transitionFromChatTo3D() {
    const executeTransition = () => {
      if (romanticChatScreen) {
        romanticChatScreen.style.opacity = '0';
        romanticChatScreen.style.transform = 'scale(0.95)';
        setTimeout(() => {
          romanticChatScreen.classList.add('hidden');
          romanticChatScreen.style.display = 'none';
          romanticChatScreen.style.opacity = '';
          romanticChatScreen.style.transform = '';
        }, 500);
      }

      currentStoryStep = 'balloons';

      // Smoothly animate 3D camera to grand celebration angle
      const grandCam = scene.getCelebrationCameraCoords();
      gsap.to(scene.camera.position, {
        x: grandCam.pos.x,
        y: grandCam.pos.y,
        z: grandCam.pos.z,
        duration: 1.6,
        ease: 'power2.out'
      });
      gsap.to(scene.controls.target, {
        x: grandCam.target.x,
        y: grandCam.target.y,
        z: grandCam.target.z,
        duration: 1.6,
        ease: 'power2.out'
      });

      // Play music & fireworks
      if (window.birthdayAudio) {
        window.birthdayAudio.init();
        window.birthdayAudio.playGiftOpen();
      }
      if (window.confetti) {
        window.confetti({ particleCount: 80, spread: 100, origin: { y: 0.5 } });
      }
    };

    // Trigger Biometric Heartbeat Scanner & Real 3D Asset Downloader
    if (window.HeartbeatLoader && typeof window.HeartbeatLoader.open === 'function') {
      window.HeartbeatLoader.open(executeTransition);
    } else {
      executeTransition();
    }
  }

  if (btnEnter3DWorld) {
    btnEnter3DWorld.addEventListener('click', transitionFromChatTo3D);
  }

  if (btnSkipChat) {
    btnSkipChat.addEventListener('click', transitionFromChatTo3D);
  }

  /* =========================================================
     STEP 3: TO REVEAL CAKE - BURST BALLOONS AROUND CAKE
     ========================================================= */
  window.onTableBalloonPopped = (remaining) => {
    trackRecipientActivity('balloon_popped', `Popped table balloon (${5 - remaining}/5) 🎈`, '🎈');
    if (questBalloonCount) questBalloonCount.textContent = remaining;
    if (questDescText && remaining > 0) {
      questDescText.textContent = `around the cake to reveal the surprise`;
    }

    // Update progress dots (gray out popped ones)
    for (let i = 0; i < 5; i++) {
      const dot = document.getElementById(`dot-${i}`);
      if (dot) {
        if (i < 5 - remaining) {
          dot.classList.remove('active');
        } else {
          dot.classList.add('active');
        }
      }
    }

    if (remaining === 0) {
      trackRecipientActivity('all_balloons_popped', 'Popped all 5 balloons — 3D Birthday Cake revealed! 🎂', '🎂');
      if (questTitleText) questTitleText.textContent = `✨ ALL BALLOONS BURST! ✨`;
      if (questDescText) questDescText.textContent = `Revealing the Birthday Cake... 🎂`;

      // 1-second pause, then zoom in & lift cloth
      setTimeout(() => {
        scene.liftAndRemoveCloth(() => {
          // Cloth removed -> Hide main screen quest card and show Burn Candles button
          if (mainScreenQuestCard) mainScreenQuestCard.classList.add('hidden');
          stepBurnCandles.classList.remove('hidden');
          currentStoryStep = 'burn-candles';
        });
      }, 1000);
    }
  };

  /* =========================================================
     STEP 3: BURN CANDLES ("BURN CANDLE")
     ========================================================= */
  stepBurnCandles.addEventListener('click', () => {
    trackRecipientActivity('candles_lit', 'Lit romantic candles on 3D Birthday Cake 🕯️', '🕯️');
    scene.lightCandles();

    // Transition to Step 4 (Cut the Cake)
    stepBurnCandles.classList.add('hidden');
    stepCutCake.classList.remove('hidden');
    currentStoryStep = 'cut-cake';
  });

  /* =========================================================
     STEP 4: CUT THE CAKE -> 3S FIREWORKS + SONG
     ========================================================= */
  stepCutCake.addEventListener('click', () => {
    trackRecipientActivity('cake_cut', 'Cut the 3D Birthday Cake & celebrated with fireworks! 🍰✨', '🍰');
    stepCutCake.classList.add('hidden');

    scene.cutCakeAndCelebrate(() => {
      // After 3-second fireworks finish -> Transition to Step 5 (Open Gift)
      stepOpenGift.classList.remove('hidden');
      currentStoryStep = 'open-gift';
    });
  });

  /* =========================================================
     STEP 5: BRING GIFT FORWARD & TAP TO OPEN
     ========================================================= */
  stepOpenGift.addEventListener('click', () => {
    trackRecipientActivity('gift_opened', 'Opened surprise 3D gift box with love message 🎁', '🎁');
    stepOpenGift.classList.add('hidden');

    // Fly gift box smoothly to front center
    scene.presentGiftBoxToCenter(() => {
      // Show "Tap Box to Open" notification
      if (tapGiftCard) tapGiftCard.classList.remove('hidden');
    });

    // Unlock full free-play dock
    guidedStoryBar.classList.add('hidden');
    freePlayBottomBar.classList.remove('hidden');
    currentStoryStep = 'free-play';
  });

  // Clicking the floating "Tap Box to Open" badge
  if (tapGiftCard) {
    tapGiftCard.addEventListener('click', () => {
      trackRecipientActivity('gift_opened', 'Opened surprise 3D gift box with love message 🎁', '🎁');
      scene.openGift();
      tapGiftCard.classList.add('hidden');
    });
  }

  /* =========================================================
     URL PARAMETERS & SHARING (PHOTO + NAME + AGE + THEME)
     ========================================================= */
  // Clear any stale local cache from previous sessions
  try {
    localStorage.removeItem('birthday_custom_photo');
  } catch(e) {}

  function compressImage(img, maxWidth = 200, maxHeight = 260, quality = 0.52) {
    const canvas = document.createElement('canvas');
    let width = img.width;
    let height = img.height;

    if (width > height) {
      if (width > maxWidth) {
        height = Math.round((height * maxWidth) / width);
        width = maxWidth;
      }
    } else {
      if (height > maxHeight) {
        width = Math.round((width * maxHeight) / height);
        height = maxHeight;
      }
    }

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(img, 0, 0, width, height);
    return canvas.toDataURL('image/jpeg', quality);
  }

  // Loads the celebrant's main photo into the 3D scene with automatic
  // retries + cache-busting. The /api/photo proxy calls Telegram's live
  // API on every request (no server-side cache), so a transient network
  // hiccup or Telegram rate-limit can make the image intermittently fail
  // to load even though the upload itself succeeded — without a retry,
  // this used to silently leave the 3D photo frame blank/default with no
  // way to recover on that view.
  function loadCelebrantPhotoWithRetry(url, attempt = 1, maxAttempts = 4) {
    if (!url) return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      if (scene && scene.updateUserPhoto) scene.updateUserPhoto(img);
    };
    img.onerror = () => {
      if (attempt < maxAttempts) {
        // Exponential-ish backoff: 0.8s, 1.6s, 3.2s
        const delay = 800 * Math.pow(2, attempt - 1);
        setTimeout(() => loadCelebrantPhotoWithRetry(url, attempt + 1, maxAttempts), delay);
      } else {
        console.warn('[Photo] Failed to load celebrant photo after retries:', url);
        // Fall back to the default frame instead of leaving it stuck blank.
        if (scene && scene.clearUserPhoto) scene.clearUserPhoto();
      }
    };
    // Cache-bust each retry so a failed/partial response isn't served from cache.
    const sep = url.includes('?') ? '&' : '?';
    img.src = attempt === 1 ? url : `${url}${sep}_retry=${attempt}_${Date.now()}`;
  }

  async function parseUrlParams() {
    const params = new URLSearchParams(window.location.search || window.location.hash.replace(/^#/, '?'));

    // === SHORT LINK: ?s=TOKEN — fetch all data from server ===
    if (params.has('s') && params.get('s').trim()) {
      const token = params.get('s').trim();
      try {
        const res = await fetch(`${API_BASE}/api/get_surprise?s=${encodeURIComponent(token)}`);
        if (res.status === 410) {
          // Link expired
          document.body.innerHTML = `
            <div style="min-height:100vh;display:flex;align-items:center;justify-content:center;
              background:#12030f;color:#fff;font-family:sans-serif;text-align:center;padding:40px;">
              <div>
                <div style="font-size:3rem;margin-bottom:16px;">⌛💔</div>
                <h2 style="color:#ff758c;">This surprise link has expired!</h2>
                <p style="color:rgba(255,255,255,0.75);">The 48-hour window has passed and this birthday surprise is no longer available. Ask the creator to send a fresh link! 🎁</p>
              </div>
            </div>`;
          return;
        }
        if (res.ok) {
          const json = await res.json();
          if (json.status === 'success' && json.data) {
            const d = json.data;
            activeSurpriseToken = token;
            if (d.username) {
              surpriseCreatorUsername = d.username.trim().toLowerCase();
            }
            if (d.name) { celebrantName = d.name; if (inputName) inputName.value = d.name; }
            if (d.age) { celebrantAge = d.age; if (inputAge) inputAge.value = d.age; }
            if (d.wish) { customWish = d.wish; if (inputWish) inputWish.value = d.wish; }
            if (d.theme) activeTheme = d.theme;
            if (d.font) celebrantFont = d.font;
            if (d.memories && Array.isArray(d.memories) && d.memories.length > 0) {
              userMemoriesPhotos = d.memories;
            }
            if (d.safarnama) {
              try {
                const parsed = typeof d.safarnama === 'string'
                  ? JSON.parse(decodeURIComponent(d.safarnama)) : d.safarnama;
                if (Array.isArray(parsed)) userSafarnamaChapters = parsed;
              } catch(e) {}
            }
            if (d.questions && Array.isArray(d.questions) && d.questions.length > 0) {
              activeChatQuestions = d.questions;
            }
            // Main portrait from server (sanitized proxy URL, resolved for display)
            const serverPhoto = d.photo ? resolvePhotoUrl(d.photo) : null;
            if (serverPhoto) currentPhotoDataUrl = d.photo;
            // Render all memories photos immediately via token-free proxy
            updateMemoriesPhoto(d.photo || null, userMemoriesPhotos);

            if (serverPhoto) {
              loadCelebrantPhotoWithRetry(serverPhoto);
            }
            if (d.upi) {
              updateUpiOrderDisplay(d.upi);
            }
            updateCelebrantInfo();
            applyTheme(activeTheme);
            trackRecipientActivity('link_opened', 'Opened magical birthday surprise link 🚀', '🚀');
            return;
          }
        }
      } catch(e) { /* fall through to normal param parsing */ }
    }

    // === LEGACY LONG URL params (backward compat) ===
    if (params.has('name')) {
      celebrantName = params.get('name');
      inputName.value = celebrantName;
    }
    if (params.has('age')) {
      celebrantAge = params.get('age');
      inputAge.value = celebrantAge;
    }
    if (params.has('wish')) {
      customWish = params.get('wish');
      inputWish.value = customWish;
    }
    if (params.has('theme')) {
      activeTheme = params.get('theme');
    }
    if (params.has('font')) {
      celebrantFont = params.get('font');
    }
    if (params.has('upi')) {
      updateUpiOrderDisplay(params.get('upi'));
    }

    // Check shared photo in URL hash/param
    let sharedPhoto = params.get('photo') || null;
    if (sharedPhoto) sharedPhoto = resolvePhotoUrl(sharedPhoto);
    currentPhotoDataUrl = sharedPhoto;
    if (inputPhotoUrl && sharedPhoto && (sharedPhoto.startsWith('http') || sharedPhoto.startsWith('/'))) {
      inputPhotoUrl.value = sharedPhoto;
    }

    // Check memories photos list in URL
    if (params.has('memories')) {
      try {
        const parsed = JSON.parse(decodeURIComponent(params.get('memories')));
        if (Array.isArray(parsed) && parsed.length > 0) {
          userMemoriesPhotos = parsed;
        }
      } catch(e) {}
    }

    updateMemoriesPhoto(sharedPhoto, userMemoriesPhotos);

    if (sharedPhoto) {
      loadCelebrantPhotoWithRetry(resolvePhotoUrl(sharedPhoto));
    } else {
      if (scene && scene.clearUserPhoto) {
        scene.clearUserPhoto();
      }
    }

    updateCelebrantInfo();
    applyTheme(activeTheme);
  }

  function updateCelebrantInfo() {
    const isCustom = celebrantName && celebrantName !== 'Birthday Star';
    const displayName = isCustom ? celebrantName : 'My Love';

    if (isCustom) {
      displayNameText.textContent = celebrantName;
      celebrantTitle.textContent = `Happy Birthday ${celebrantName}!`;
      bannerTitle.textContent = `${celebrantName.toUpperCase()}`;
      document.title = `✨ Happy Birthday ${celebrantName}! 🎉`;
    } else {
      displayNameText.textContent = 'Happy Birthday';
      celebrantTitle.textContent = 'Happy Birthday!';
      bannerTitle.textContent = 'HAPPY BIRTHDAY';
      document.title = '✨ Happy Birthday Celebration! 🎉';
    }

    if (celebrantAge && parseInt(celebrantAge) > 0) {
      displayAgeBadge.textContent = celebrantAge;
      displayAgeBadge.style.display = 'inline-block';
    } else {
      displayAgeBadge.style.display = 'none';
    }

    giftCustomWish.textContent = `"${customWish}"`;

    // --- Update Curtain Intro Screen ---
    const introHeadline = document.querySelector('.intro-headline');
    const introSubtext = document.querySelector('.intro-subtext');
    const introSparkle = document.querySelector('.intro-sparkle-badge');
    if (introHeadline) introHeadline.textContent = `Happy Birthday ${displayName}! ✨`;
    if (introSubtext && customWish && customWish !== 'Happy Birthday!') {
      introSubtext.textContent = customWish.length > 80 ? customWish.substring(0, 80) + '...' : customWish;
    }

    // --- Update Romantic Chat Screen Hero ---
    const romanticHeroTitle = document.querySelector('.romantic-hero-title');
    const romanticHeroSub = document.querySelector('.romantic-hero-subtitle');
    if (romanticHeroTitle) romanticHeroTitle.textContent = `Happy Birthday, ${displayName}! 💖`;
    if (romanticHeroSub && customWish && customWish !== 'Happy Birthday!') {
      const shortWish = customWish.length > 90 ? customWish.substring(0, 90) + '...' : customWish;
      romanticHeroSub.textContent = `"${shortWish}"`;
    }

    // Real-time update to 3D Stand Board, Numeric Candles & Photo Frame
    if (scene && scene.updateCelebrantInfo3D) {
      scene.updateCelebrantInfo3D(celebrantName, celebrantAge, celebrantFont);
    }
  }

  // --- Lightbox overlay for full image preview (original resolution) ---
  function openMemoryLightbox(src) {
    if (!src) return;
    src = resolvePhotoUrl(src);
    let lb = document.getElementById('memory-lightbox-overlay');
    if (!lb) {
      lb = document.createElement('div');
      lb.id = 'memory-lightbox-overlay';
      lb.style.cssText = `position:fixed;inset:0;background:rgba(0,0,0,0.92);z-index:999999;
        display:flex;align-items:center;justify-content:center;cursor:zoom-out;
        animation:fadeIn 0.2s ease;padding:20px;`;
      const lbImg = document.createElement('img');
      lbImg.id = 'memory-lightbox-img';
      lbImg.style.cssText = `max-width:92vw;max-height:88vh;border-radius:16px;
        box-shadow:0 20px 80px rgba(255,117,140,0.6);object-fit:contain;
        border:3px solid rgba(255,117,140,0.7);background:#12030f;`;
      const lbClose = document.createElement('button');
      lbClose.textContent = '✕';
      lbClose.title = 'Close Photo Preview';
      lbClose.style.cssText = `position:fixed;top:20px;right:24px;background:#ff0a54;
        color:#fff;border:none;border-radius:50%;width:42px;height:42px;font-size:1.2rem;
        cursor:pointer;font-weight:700;z-index:1000000;box-shadow:0 4px 15px rgba(255,10,84,0.6);
        display:flex;align-items:center;justify-content:center;`;
      lb.appendChild(lbImg);
      lb.appendChild(lbClose);
      document.body.appendChild(lb);
      lb.addEventListener('click', (e) => { if (e.target === lb || e.target === lbClose) lb.remove(); });
    }
    const imgEl = document.getElementById('memory-lightbox-img');
    if (imgEl) imgEl.src = resolvePhotoUrl(src);
  }

  // --- Inject uploaded photos into all memory/polaroid frames ---
  function updateMemoriesPhoto(photoUrl, photosArray) {
    // Normalize: accept both plain strings and {cdnUrl, localUrl} objects
    function toSrcUrl(item) {
      if (!item) return null;
      if (typeof item === 'string') {
        const s = item.trim();
        if (!s || s === 'null' || s === 'undefined') return null;
        return resolvePhotoUrl(s);
      }
      if (typeof item === 'object') {
        const u = (item.cdnUrl || item.localUrl || item.url || '').trim();
        if (!u || u === 'null' || u === 'undefined') return null;
        return resolvePhotoUrl(u);
      }
      return null;
    }

    const collected = [];

    // 1. Add main portrait photo first if available
    const mainSrc = toSrcUrl(photoUrl || currentPhotoDataUrl);
    if (mainSrc && !collected.includes(mainSrc)) {
      collected.push(mainSrc);
    }

    // 2. Add photos from argument array
    if (Array.isArray(photosArray)) {
      photosArray.forEach(p => {
        const u = toSrcUrl(p);
        if (u && !collected.includes(u)) collected.push(u);
      });
    }

    // 3. Add photos from global userMemoriesPhotos
    if (Array.isArray(userMemoriesPhotos)) {
      userMemoriesPhotos.forEach(p => {
        const u = toSrcUrl(p);
        if (u && !collected.includes(u)) collected.push(u);
      });
    }

    const photosList = collected;

    // 1. Book memories modal polaroid cards (#modal-book-memories)
    const memoriesGridWrapper = document.querySelector('#modal-book-memories .memories-grid-wrapper');
    if (memoriesGridWrapper && photosList.length > 0) {
      const captions = [
        "Where Our Story Began ✨",
        "That Unforgettable Smile 🥰",
        "Endless Laughs & Calls 🌙",
        "Celebrating Your Special Day 👑",
        "Precious Moments Together 💕",
        "Pure Love & Happiness ❤️",
        "Forever My Favorite View ✨",
        "Sweet Birthday Memories 💖",
        "You Make My World Beautiful 🌸",
        "A Thousand Beautiful Smiles 💫"
      ];

      let html = '';
      photosList.forEach((src, idx) => {
        const captionText = captions[idx % captions.length] || `Memory #${idx + 1} ✨`;
        html += `
          <div class="polaroid-memory-card" data-src="${src}" style="cursor: pointer;" title="Click to view full photo">
            <div class="polaroid-inner-frame">
              <div class="polaroid-sample-img" style="position: relative; overflow: hidden; background: #200418; border-radius: 6px;">
                <img src="${src}" alt="${captionText}" class="polaroid-real-img" style="width: 100%; height: 170px; object-fit: cover; display: block; transition: transform 0.3s ease;">
                <div style="position: absolute; bottom: 6px; right: 6px; background: rgba(0,0,0,0.65); color: #fff; border-radius: 50%; width: 26px; height: 26px; display: flex; align-items: center; justify-content: center; font-size: 0.72rem;">
                  <i class="fa-solid fa-expand"></i>
                </div>
              </div>
              <div class="polaroid-caption">${captionText}</div>
            </div>
          </div>
        `;
      });
      memoriesGridWrapper.innerHTML = html;

      // Click any polaroid to zoom in lightbox
      memoriesGridWrapper.querySelectorAll('.polaroid-memory-card').forEach(card => {
        card.addEventListener('click', () => {
          const src = card.getAttribute('data-src');
          if (src) openMemoryLightbox(src);
        });
      });
    }

    // 2. Polaroids modal in drawer (#polaroids-modal)
    const polaroidsGrid = document.querySelector('#polaroids-modal .polaroids-grid');
    if (polaroidsGrid && photosList.length > 0) {
      let drawerHtml = '';
      const drawerCaptions = [
        "The moment I fell for you ❤️",
        "Every second with you is pure joy 💖",
        "To many more adventures together 🥂",
        "You are my whole universe 👑",
        "Forever and always in love 💕",
        "Our sweetest birthday memory ✨"
      ];
      photosList.forEach((src, idx) => {
        const cap = drawerCaptions[idx % drawerCaptions.length] || `Memory #${idx + 1} 💕`;
        drawerHtml += `
          <div class="polaroid-item" data-src="${src}" style="cursor: pointer;" title="Click to view full photo">
            <div class="polaroid-photo-frame" style="position: relative; overflow: hidden;">
              <img src="${src}" alt="Memory ${idx + 1}" class="polaroid-preview-img" style="width: 100%; height: 100%; object-fit: cover; display: block;">
            </div>
            <p class="polaroid-caption">"${cap}"</p>
          </div>
        `;
      });
      polaroidsGrid.innerHTML = drawerHtml;
      polaroidsGrid.querySelectorAll('.polaroid-item').forEach(item => {
        item.addEventListener('click', () => {
          const src = item.getAttribute('data-src');
          if (src) openMemoryLightbox(src);
        });
      });
    }

    // 3. Update 3D Book Cover on Landing / Chat Screen (#book-card-memories)
    const miniPreview = document.querySelector('#book-card-memories .mini-polaroid-preview');
    if (miniPreview && photosList.length > 0) {
      miniPreview.innerHTML = `
        <img src="${photosList[0]}" alt="Cover Photo" class="book-cover-mini-photo" style="width: 100%; height: 100%; object-fit: cover; border-radius: 6px; box-shadow: 0 4px 12px rgba(0,0,0,0.4); display: block;">
        <span class="polaroid-sparkle" style="position: absolute; top: -6px; right: -6px;">💖</span>
      `;
    }

    // 4. Update 3D Scene easel frame if available
    if (scene && scene.updateUserPhoto && photosList.length > 0) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try { scene.updateUserPhoto(img); } catch(e) {}
      };
      img.src = photosList[0];
    }
  }

  function generateShareUrl(includePhoto = true) {
    const url = new URL(window.location.href);
    url.search = '';
    const params = new URLSearchParams();
    params.set('name', celebrantName || 'Birthday Star');
    if (celebrantAge) params.set('age', celebrantAge);
    params.set('wish', customWish || 'Happy Birthday!');
    params.set('theme', activeTheme || 'midnight-gold');
    if (includePhoto && currentPhotoDataUrl) {
      params.set('photo', currentPhotoDataUrl);
    }
    if (creatorUpiId) {
      params.set('upi', creatorUpiId);
    }
    url.hash = params.toString();
    return url.toString();
  }

  /* =========================================================
     THEME SELECTOR
     ========================================================= */
  function applyTheme(themeName) {
    activeTheme = themeName;
    document.body.className = `theme-${themeName}`;
    scene.setTheme(themeName);

    document.querySelectorAll('.drawer-theme-pill').forEach(opt => {
      if (opt.getAttribute('data-theme') === themeName) {
        opt.classList.add('active');
      } else {
        opt.classList.remove('active');
      }
    });
  }

  document.querySelectorAll('.drawer-theme-pill').forEach(opt => {
    opt.addEventListener('click', () => {
      const theme = opt.getAttribute('data-theme');
      applyTheme(theme);
    });
  });

  /* =========================================================
     AUDIO CONTROLS
     ========================================================= */
  if (musicToggleBtn) {
    musicToggleBtn.addEventListener('click', () => {
      const isPlaying = (window.birthdayAudio && window.birthdayAudio.toggleMusic) ? window.birthdayAudio.toggleMusic() : false;
      if (soundWave) {
        if (isPlaying) {
          soundWave.classList.add('playing');
        } else {
          soundWave.classList.remove('playing');
        }
      }
    });
  }

  /* =========================================================
     CAMERA VIEWS (DRAWER)
     ========================================================= */
  Object.keys(camPills).forEach(key => {
    const btn = camPills[key];
    if (btn) {
      btn.addEventListener('click', () => {
        Object.values(camPills).forEach(b => { if (b) b.classList.remove('active'); });
        btn.classList.add('active');
        if (scene && scene.setCameraView) scene.setCameraView(key);
        closeMenuDrawer();
      });
    }
  });

  /* =========================================================
     FEATURE TOGGLES (DRAWER)
     ========================================================= */
  const btnDiscoMode = document.getElementById('btn-disco-mode');
  if (btnDiscoMode) {
    btnDiscoMode.addEventListener('click', () => {
      const isActive = (scene && scene.toggleDiscoMode) ? scene.toggleDiscoMode() : false;
      btnDiscoMode.classList.toggle('active', isActive);
    });
  }

  if (btnSparklerWand) {
    btnSparklerWand.addEventListener('click', () => {
      if (scene) {
        scene.sparklerActive = !scene.sparklerActive;
        btnSparklerWand.classList.toggle('active', scene.sparklerActive);
        document.body.classList.toggle('sparkler-active', scene.sparklerActive);
      }
    });
  }

  if (btnSkyLanterns) {
    btnSkyLanterns.addEventListener('click', () => {
      closeMenuDrawer();
      if (scene) {
        scene.setCameraView('fireworks');
        Object.values(camPills).forEach(b => { if (b) b.classList.remove('active'); });
        if (camPills.fireworks) camPills.fireworks.classList.add('active');
        scene.start3SecondFirecrackers();
      }
    });
  }

  if (btnPhotoBooth) {
    btnPhotoBooth.addEventListener('click', () => {
      closeMenuDrawer();
      generatePostcard();
    });
  }

  function generatePostcard() {
    if (!scene || !scene.renderer) return;
    const canvas = scene.renderer.domElement;
    const postCanvas = document.createElement('canvas');
    postCanvas.width = 1200;
    postCanvas.height = 900;
    const ctx = postCanvas.getContext('2d');

    const bgGrad = ctx.createLinearGradient(0, 0, 1200, 900);
    bgGrad.addColorStop(0, '#1a103c');
    bgGrad.addColorStop(0.5, '#0c071e');
    bgGrad.addColorStop(1, '#05020c');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 1200, 900);

    ctx.strokeStyle = '#ffd700';
    ctx.lineWidth = 14;
    ctx.strokeRect(30, 30, 1140, 840);

    ctx.drawImage(canvas, 60, 60, 1080, 620);

    ctx.strokeStyle = 'rgba(255, 215, 0, 0.5)';
    ctx.lineWidth = 4;
    ctx.strokeRect(60, 60, 1080, 620);

    ctx.fillStyle = '#ffd700';
    ctx.font = 'bold 44px Outfit, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(`✨ HAPPY BIRTHDAY ${celebrantName.toUpperCase()}! ✨`, 600, 735);

    ctx.fillStyle = '#f0f0ff';
    ctx.font = 'italic 22px Playfair Display, serif';
    ctx.fillText(`"${customWish}"`, 600, 785);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
    ctx.font = '18px Outfit, sans-serif';
    const ageTag = (celebrantAge && parseInt(celebrantAge) > 0) ? ` • Age ${celebrantAge}` : '';
    ctx.fillText(`Celebrated with Love • ${celebrantName}${ageTag}`, 600, 835);

    const dataUrl = postCanvas.toDataURL('image/png');
    if (postcardPreviewImg) postcardPreviewImg.src = dataUrl;
    if (btnDownloadPostcard) btnDownloadPostcard.href = dataUrl;
    if (photoBoothModal) photoBoothModal.classList.add('show');
  }

  if (closePhotoModal && photoBoothModal) {
    closePhotoModal.addEventListener('click', () => photoBoothModal.classList.remove('show'));
  }

  // Arcade Game
  if (btnArcadeGame) {
    btnArcadeGame.addEventListener('click', () => {
      closeMenuDrawer();
      startArcadeGame();
    });
  }

  function startArcadeGame() {
    let arcadeScore = 0;
    let arcadeCombo = 1;
    let arcadeTimeLeft = 30;

    if (arcadeScoreVal) arcadeScoreVal.textContent = '0000';
    if (arcadeComboVal) arcadeComboVal.textContent = 'x1';
    if (arcadeTimerVal) arcadeTimerVal.textContent = '30s';
    if (arcadeTimerFill) arcadeTimerFill.style.width = '100%';

    if (arcadeHud) arcadeHud.classList.add('active');

    const timerInt = setInterval(() => {
      arcadeTimeLeft--;
      if (arcadeTimerVal) arcadeTimerVal.textContent = `${arcadeTimeLeft}s`;
      if (arcadeTimerFill) arcadeTimerFill.style.width = `${(arcadeTimeLeft / 30) * 100}%`;

      if (arcadeTimeLeft <= 0) {
        clearInterval(timerInt);
        if (arcadeHud) arcadeHud.classList.remove('active');
        if (finalScoreVal) finalScoreVal.textContent = String(arcadeScore);
        if (finalRankBadge) finalRankBadge.textContent = arcadeScore > 800 ? "🎉 CELEBRATION MASTER 🎉" : "⭐ PARTY PRO ⭐";
        if (window.birthdayAudio) window.birthdayAudio.playGameOverFanfare();
        if (arcadeOverModal) arcadeOverModal.classList.add('show');
      }
    }, 1000);

    if (btnQuitArcade) {
      btnQuitArcade.onclick = () => {
        clearInterval(timerInt);
        if (arcadeHud) arcadeHud.classList.remove('active');
      };
    }
  }

  if (btnReplayArcade && arcadeOverModal) {
    btnReplayArcade.addEventListener('click', () => {
      arcadeOverModal.classList.remove('show');
      startArcadeGame();
    });
  }

  if (btnCloseArcadeModal && arcadeOverModal) {
    btnCloseArcadeModal.addEventListener('click', () => arcadeOverModal.classList.remove('show'));
  }

  /* =========================================================
     FREE PLAY BUTTONS
     ========================================================= */
  if (btnLaunchFireworks) {
    btnLaunchFireworks.addEventListener('click', () => {
      if (scene) {
        scene.setCameraView('fireworks');
        Object.values(camPills).forEach(b => { if (b) b.classList.remove('active'); });
        if (camPills.fireworks) camPills.fireworks.classList.add('active');
        scene.start3SecondFirecrackers();
      }
    });
  }

  const canvasContainer = document.getElementById('canvas-container');
  if (canvasContainer) {
    canvasContainer.addEventListener('click', () => {
      if (camPills.fireworks && camPills.fireworks.classList.contains('active')) {
        if (scene) scene.start3SecondFirecrackers();
      }
    });
  }

  if (btnOpenGift) {
    btnOpenGift.addEventListener('click', () => {
      if (scene) {
        scene.setCameraView('gift');
        Object.values(camPills).forEach(b => { if (b) b.classList.remove('active'); });
        if (camPills.gift) camPills.gift.classList.add('active');
        scene.openGift();
      }
    });
  }

  if (btnSpawnBalloons) {
    btnSpawnBalloons.addEventListener('click', () => {
      if (scene) scene.createTableBalloons(5);
      if (window.confetti) window.confetti({ particleCount: 40, spread: 70, origin: { y: 0.8 } });
    });
  }

  if (btnBlowCandles) {
    btnBlowCandles.addEventListener('click', () => {
      if (scene) {
        scene.setCameraView('cake');
        Object.values(camPills).forEach(b => { if (b) b.classList.remove('active'); });
        if (camPills.cake) camPills.cake.classList.add('active');
        if (typeof scene.blowCandles === 'function') {
          scene.blowCandles();
        }
        scene.start3SecondFirecrackers();
      }
    });
  }

  /* =========================================================
     MODAL CONTROLS & FORMS
     ========================================================= */
  if (customizeBtn && customizeModal) {
    customizeBtn.addEventListener('click', () => {
      closeMenuDrawer();
      customizeModal.classList.add('show');
    });
  }
  if (closeCustomizeModal && customizeModal) {
    closeCustomizeModal.addEventListener('click', () => customizeModal.classList.remove('show'));
  }

  if (customizeForm) {
    customizeForm.addEventListener('submit', (e) => {
      e.preventDefault();
      celebrantName = inputName ? (inputName.value.trim() || 'Birthday Star') : 'Birthday Star';
      celebrantAge = inputAge ? (inputAge.value.trim() || '') : '';
      customWish = inputWish ? (inputWish.value.trim() || 'Happy Birthday!') : 'Happy Birthday!';

      const inputUpiEl = document.getElementById('input-upi');
      if (inputUpiEl && inputUpiEl.value.trim()) {
        updateUpiOrderDisplay(inputUpiEl.value.trim());
      }

      updateCelebrantInfo();
      if (currentPhotoDataUrl) updateMemoriesPhoto(currentPhotoDataUrl);
      if (customizeModal) customizeModal.classList.remove('show');
      if (scene) scene.start3SecondFirecrackers();
    });
  }

  if (inputPhoto) {
    inputPhoto.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (file) {
        if (photoFilename) photoFilename.textContent = file.name;
        if (photoUploadStatus) {
          photoUploadStatus.textContent = '⏳ Preparing photo for cloud sharing...';
          photoUploadStatus.className = 'photo-upload-status show';
        }

        const reader = new FileReader();
        reader.onload = (event) => {
          const img = new Image();
          img.onload = () => {
            const compressed = compressImage(img);
            currentPhotoDataUrl = compressed;
            try {
              localStorage.setItem('birthday_custom_photo', compressed);
            } catch(err) {}
            if (scene) scene.updateUserPhoto(img);
            updateMemoriesPhoto(compressed);

            if (photoUploadStatus) {
              photoUploadStatus.textContent = '✅ Photo ready for 3D experience!';
              photoUploadStatus.className = 'photo-upload-status show success';
            }
          };
          img.src = event.target.result;
        };
        reader.readAsDataURL(file);
      }
    });
  }

  if (inputPhotoUrl) {
    inputPhotoUrl.addEventListener('input', () => {
      const url = inputPhotoUrl.value.trim();
      if (url && (url.startsWith('http://') || url.startsWith('https://') || url.startsWith('data:image'))) {
        currentPhotoDataUrl = url;
        try { localStorage.setItem('birthday_custom_photo', url); } catch(e) {}
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          if (scene) scene.updateUserPhoto(img);
          if (photoUploadStatus) {
            photoUploadStatus.textContent = '✅ Photo loaded successfully from URL!';
            photoUploadStatus.className = 'photo-upload-status show success';
          }
        };
        img.onerror = () => {
          if (photoUploadStatus) {
            photoUploadStatus.textContent = '⚠️ Check image URL (must be direct image link)';
            photoUploadStatus.className = 'photo-upload-status show error';
          }
        };
        img.src = url;
      }
    });
  }

  /* =========================================================
     LOVE LETTER & POLAROID MODALS
     ========================================================= */
  if (btnLoveLetter) {
    btnLoveLetter.addEventListener('click', () => {
      closeMenuDrawer();
      giftModal.classList.add('show');
    });
  }

  if (btnMemoryGallery) {
    btnMemoryGallery.addEventListener('click', () => {
      closeMenuDrawer();
      updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);
      if (polaroidsModal) polaroidsModal.classList.add('show');
    });
  }

  if (closePolaroidsModal) {
    closePolaroidsModal.addEventListener('click', () => {
      polaroidsModal.classList.remove('show');
    });
  }

  if (btnOpenCustomizerFromPolaroids) {
    btnOpenCustomizerFromPolaroids.addEventListener('click', () => {
      polaroidsModal.classList.remove('show');
      customizeModal.classList.add('show');
    });
  }

  if (closeGiftModal) {
    closeGiftModal.addEventListener('click', () => giftModal.classList.remove('show'));
  }
  if (btnGiftGoToOrders) {
    btnGiftGoToOrders.addEventListener('click', () => {
      giftModal.classList.remove('show');
      openFullScreenOrderHub(false);
    });
  }
  if (btnGiftReplay) {
    btnGiftReplay.addEventListener('click', () => {
      giftModal.classList.remove('show');
      openFullScreenOrderHub(false);
    });
  }

  shareBtn.addEventListener('click', () => {
    closeMenuDrawer();
    const shareUrl = generateShareUrl(true); // Includes Photo in Link!
    const qrUrl = generateShareUrl(false); // Clean URL for QR Code
    shareLinkInput.value = shareUrl;
    copyFeedback.classList.remove('show');

    if (window.QRCode && qrcodeContainer) {
      try {
        qrcodeContainer.innerHTML = '';
        qrcodeInstance = new QRCode(qrcodeContainer, {
          text: qrUrl,
          width: 170,
          height: 170,
          colorDark: "#380c25",
          colorLight: "#ffffff",
          correctLevel: QRCode.CorrectLevel.M
        });
      } catch(qrErr) {
        console.warn('QR Code generation notice:', qrErr);
      }
    }
    shareModal.classList.add('show');
  });

  closeShareModal.addEventListener('click', () => shareModal.classList.remove('show'));

  btnCopyLink.addEventListener('click', () => {
    shareLinkInput.select();
    shareLinkInput.setSelectionRange(0, 99999);
    try {
      navigator.clipboard.writeText(shareLinkInput.value).then(() => {
        copyFeedback.classList.add('show');
        setTimeout(() => copyFeedback.classList.remove('show'), 3000);
      }).catch(() => {
        document.execCommand('copy');
        copyFeedback.classList.add('show');
        setTimeout(() => copyFeedback.classList.remove('show'), 3000);
      });
    } catch(err) {
      document.execCommand('copy');
      copyFeedback.classList.add('show');
      setTimeout(() => copyFeedback.classList.remove('show'), 3000);
    }
  });

  /* =========================================================
     LIVE CAMERA TELEMETRY INSPECTOR HUD LOGIC
     ========================================================= */
  const btnToggleCamInspector = document.getElementById('btn-toggle-cam-inspector');
  const cameraTelemetryHud = document.getElementById('camera-telemetry-hud');
  const closeHudBtn = document.getElementById('close-hud-btn');
  const metricCamDist = document.getElementById('metric-cam-dist');
  const metricCamPitch = document.getElementById('metric-cam-pitch');
  const metricCamYaw = document.getElementById('metric-cam-yaw');
  const metricCamPos = document.getElementById('metric-cam-pos');
  const metricCamTarget = document.getElementById('metric-cam-target');
  const camDistanceSlider = document.getElementById('cam-distance-slider');
  const sliderDistVal = document.getElementById('slider-dist-val');
  const btnCopyCamCoords = document.getElementById('btn-copy-cam-coords');
  const copyCamText = document.getElementById('copy-cam-text');

  let currentTelemetry = null;

  if (btnToggleCamInspector) {
    btnToggleCamInspector.addEventListener('click', () => {
      cameraTelemetryHud.classList.toggle('show');
      closeMenuDrawer();
    });
  }

  if (closeHudBtn) {
    closeHudBtn.addEventListener('click', () => {
      cameraTelemetryHud.classList.remove('show');
    });
  }

  window.onCameraTelemetryUpdate = (data) => {
    currentTelemetry = data;
    if (!cameraTelemetryHud.classList.contains('show')) return;

    metricCamDist.textContent = `${data.distance.toFixed(1)} u`;
    metricCamPitch.textContent = `${data.pitch.toFixed(1)}°`;
    metricCamYaw.textContent = `${data.yaw.toFixed(1)}°`;

    metricCamPos.textContent = `X: ${data.pos.x.toFixed(1)}, Y: ${data.pos.y.toFixed(1)}, Z: ${data.pos.z.toFixed(1)}`;
    metricCamTarget.textContent = `X: ${data.target.x.toFixed(1)}, Y: ${data.target.y.toFixed(1)}, Z: ${data.target.z.toFixed(1)}`;

    if (document.activeElement !== camDistanceSlider) {
      camDistanceSlider.value = data.distance;
      sliderDistVal.textContent = `${data.distance.toFixed(1)} u`;
    }
  };

  if (camDistanceSlider) {
    camDistanceSlider.addEventListener('input', (e) => {
      const dist = parseFloat(e.target.value);
      sliderDistVal.textContent = `${dist.toFixed(1)} u`;
      scene.setCameraDistance(dist);
    });
  }

  if (btnCopyCamCoords) {
    btnCopyCamCoords.addEventListener('click', () => {
      if (!currentTelemetry) return;
      const t = currentTelemetry;
      const textToCopy = `camera: { x: ${t.pos.x.toFixed(2)}, y: ${t.pos.y.toFixed(2)}, z: ${t.pos.z.toFixed(2)} }, target: { x: ${t.target.x.toFixed(2)}, y: ${t.target.y.toFixed(2)}, z: ${t.target.z.toFixed(2)} }, distance: ${t.distance.toFixed(1)}, pitch: ${t.pitch.toFixed(1)}°, yaw: ${t.yaw.toFixed(1)}°`;
      
      navigator.clipboard.writeText(textToCopy).then(() => {
        copyCamText.textContent = "✅ Copied to Clipboard!";
        setTimeout(() => {
          copyCamText.textContent = "Copy Angle & Distance";
        }, 2500);
      });
    });
  }

  /* =========================================================
     DUAL BOOK ALBUMS: MEMORIES & SAFARNAMA HANDLERS
     ========================================================= */
  const bookCardMemories = document.getElementById('book-card-memories');
  const bookCardSafarnama = document.getElementById('book-card-safarnama');
  const modalBookMemories = document.getElementById('modal-book-memories');
  const modalBookSafarnama = document.getElementById('modal-book-safarnama');
  const closeModalMemories = document.getElementById('close-modal-memories');
  const closeModalSafarnama = document.getElementById('close-modal-safarnama');
  const btnOpenCustomizerFromAlbum = document.getElementById('btn-open-customizer-from-album');
  const btnSafarnamaToChat = document.getElementById('btn-safarnama-to-chat');

  // --- Dynamic Safarnama Chapters State ---
  const DEFAULT_SAFARNAMA_PRESETS = [
    {
      heading: "Jab Tum Zindagi Me Aaye 🌸",
      description: "Ek aam sa din tha, lekin jab tum meri zindagi me aayi, toh har lamha khaas ban gaya. Tumhari muskurahat ne dil ko ek aisi sukoon di jo pehle kabhi mehsoos nahi hui thi."
    },
    {
      heading: "Der Raat Ki Baatein & Silly Fights 🥰",
      description: "Wo ghanton phone par baatein karna, bina kisi wajah ke muskurana, choti-choti baaton par ruthna aur phir ek pyare se sorry par maan jana... Ye saare pal mere dil ke sabse kareeb hain."
    },
    {
      heading: "Har Kadam Par Saath 🤝",
      description: "Chahe din achha ho ya mushkil, tumne hamesha meri himmat badhayi hai. Tum sirf meri girlfriend nahi, meri sabse achhi dost aur meri sabse badi taakat ho."
    },
    {
      heading: "Aaj, Kal Aur Hamesha ❤️",
      description: "Aaj tumhare is khaas janamdin par, main rab se bas yahi dua karta hu ki tumhari har khwahish puri ho. Tumhari aankhon me hamesha khushi ke aansu hon aur hothon par pyari hasi. Happy Birthday My Love! 💖"
    }
  ];

  let userSafarnamaChapters = JSON.parse(JSON.stringify(DEFAULT_SAFARNAMA_PRESETS));

  // Render Safarnama Builder in Creator Dashboard
  function renderSafarnamaBuilder() {
    const listEl = document.getElementById('safarnama-builder-list');
    if (!listEl) return;

    listEl.innerHTML = '';
    userSafarnamaChapters.forEach((ch, idx) => {
      const card = document.createElement('div');
      card.className = 'safarnama-entry-card';
      const numStr = String(idx + 1).padStart(2, '0');
      card.innerHTML = `
        <div class="safarnama-entry-top">
          <span class="safarnama-chapter-tag"><i class="fa-solid fa-feather-pointed"></i> Chapter ${numStr}</span>
          ${userSafarnamaChapters.length > 1 ? `<button type="button" class="btn-remove-chapter" data-idx="${idx}"><i class="fa-solid fa-trash-can"></i> Remove</button>` : ''}
        </div>
        <div class="safarnama-inputs-grid">
          <div class="safarnama-input-group">
            <label><i class="fa-solid fa-heading"></i> Chapter Heading / Title</label>
            <input type="text" class="chapter-heading-input" data-idx="${idx}" placeholder="e.g. Jab Tum Zindagi Me Aaye 🌸" value="${ch.heading ? ch.heading.replace(/"/g, '&quot;') : ''}">
          </div>
          <div class="safarnama-input-group">
            <label><i class="fa-solid fa-align-left"></i> Story / Description</label>
            <textarea class="chapter-desc-input" data-idx="${idx}" rows="2" placeholder="Write the memory or story for this chapter...">${ch.description || ''}</textarea>
          </div>
        </div>
      `;
      listEl.appendChild(card);
    });

    // Heading change listener
    listEl.querySelectorAll('.chapter-heading-input').forEach(inp => {
      inp.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.idx, 10);
        if (userSafarnamaChapters[idx]) {
          userSafarnamaChapters[idx].heading = e.target.value;
          if (currentPortalUser) saveUserFormData(currentPortalUser);
        }
      });
    });

    // Description change listener
    listEl.querySelectorAll('.chapter-desc-input').forEach(txt => {
      txt.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.idx, 10);
        if (userSafarnamaChapters[idx]) {
          userSafarnamaChapters[idx].description = e.target.value;
          if (currentPortalUser) saveUserFormData(currentPortalUser);
        }
      });
    });

    // Remove button listener
    listEl.querySelectorAll('.btn-remove-chapter').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.currentTarget.dataset.idx, 10);
        userSafarnamaChapters.splice(idx, 1);
        renderSafarnamaBuilder();
        if (currentPortalUser) saveUserFormData(currentPortalUser);
      });
    });
  }

  const btnAddSafarnamaChapter = document.getElementById('btn-add-safarnama-chapter');
  if (btnAddSafarnamaChapter) {
    btnAddSafarnamaChapter.addEventListener('click', () => {
      const nextNum = userSafarnamaChapters.length + 1;
      userSafarnamaChapters.push({
        heading: `Khaas Lamha ${nextNum} 💕`,
        description: "Ek aur khoobsurat yaadein jo humare dil ke kareeb hain..."
      });
      renderSafarnamaBuilder();
      if (currentPortalUser) saveUserFormData(currentPortalUser);
      if (window.birthdayAudio) {
        try { window.birthdayAudio.playPop(); } catch(e) {}
      }
    });
  }

  const btnResetSafarnama = document.getElementById('btn-reset-safarnama');
  if (btnResetSafarnama) {
    btnResetSafarnama.addEventListener('click', () => {
      if (confirm('Reset Safarnama chapters to romantic presets?')) {
        userSafarnamaChapters = JSON.parse(JSON.stringify(DEFAULT_SAFARNAMA_PRESETS));
        renderSafarnamaBuilder();
        if (currentPortalUser) saveUserFormData(currentPortalUser);
      }
    });
  }

  if (bookCardMemories) {
    bookCardMemories.addEventListener('click', () => {
      // Inject all memory photos into memories modal when it opens
      updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);
      if (modalBookMemories) modalBookMemories.classList.add('show');
      if (window.birthdayAudio) {
        try { window.birthdayAudio.playGiftOpen(); } catch(e) {}
      }
    });
  }

  if (closeModalMemories) {
    closeModalMemories.addEventListener('click', () => {
      if (modalBookMemories) modalBookMemories.classList.remove('show');
    });
  }

  if (btnOpenCustomizerFromAlbum) {
    btnOpenCustomizerFromAlbum.addEventListener('click', () => {
      if (modalBookMemories) modalBookMemories.classList.remove('show');
      if (customizeModal) customizeModal.classList.add('show');
    });
  }

  // Helper: Transition to Live Chat when user clicks "Follow in Chat"
  function transitionToRealChat() {
    if (modalBookSafarnama) modalBookSafarnama.classList.remove('show');
    if (modalBookMemories) modalBookMemories.classList.remove('show');

    // Ensure story containers are visible
    if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
    if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
    if (curtainContainer) curtainContainer.style.display = 'none';

    const romanticChatScreen = document.getElementById('romantic-chat-screen');
    if (romanticChatScreen) {
      romanticChatScreen.classList.remove('hidden');
      romanticChatScreen.style.opacity = '1';
      romanticChatScreen.style.transform = 'none';
    }

    if (isAutomatedChatPaused && btnResumeQuestions) {
      btnResumeQuestions.classList.remove('hidden');
    }

    const chatCard = document.querySelector('.chat-card-window');
    if (chatCard) {
      chatCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const chatInput = document.getElementById('chat-user-input');
      if (chatInput && !chatInput.disabled) {
        setTimeout(() => chatInput.focus(), 600);
      }
    }
    if (window.birthdayAudio) {
      try { window.birthdayAudio.playPop(); } catch(e) {}
    }
  }

  // --- Safarnama: Dynamically populate custom chapters with Follow In Chat Buttons ---
  function renderSafarnamaChapters() {
    const chaptersScroll = document.querySelector('.safarnama-chapters-scroll');
    if (!chaptersScroll) return;

    const history = getSavedChatHistory();
    const name = celebrantName && celebrantName !== 'Birthday Star' ? celebrantName : 'Tum';

    const chaptersToRender = (userSafarnamaChapters && userSafarnamaChapters.length > 0) ? userSafarnamaChapters : DEFAULT_SAFARNAMA_PRESETS;

    let html = '';

    // Render each custom chapter filled by user
    chaptersToRender.forEach((ch, idx) => {
      const isHighlight = idx === chaptersToRender.length - 1;
      const numStr = String(idx + 1).padStart(2, '0');
      const heading = ch.heading || `Chapter ${numStr}`;
      const desc = ch.description || '';

      html += `
        <div class="safarnama-chapter-card${isHighlight ? ' highlight-chapter' : ''}">
          <div class="chapter-badge">Chapter ${numStr}</div>
          <h3 class="chapter-title">${heading}</h3>
          <p class="chapter-text">${desc}</p>
          <div class="chapter-follow-chat-row">
            <button type="button" class="btn-chapter-follow-chat" data-chapter="${numStr}" data-heading="${heading.replace(/"/g, '&quot;')}" data-desc="${desc.substring(0, 100).replace(/"/g, '&quot;')}" title="Continue in Live Chat">
              <i class="fa-solid fa-comments"></i> Follow in Chat 💬
            </button>
          </div>
        </div>`;
    });

    // Add chapters from girlfriend's live chat answers if any
    if (history.length > 0) {
      html += `
        <div class="safarnama-chapter-card" style="background: linear-gradient(135deg, rgba(255,117,140,0.12), rgba(255,200,124,0.08)); border-left: 3px solid #ff758c;">
          <div class="chapter-badge" style="background: linear-gradient(135deg, #ff758c, #ffd700);">Her Words 💬</div>
          <h3 class="chapter-title">${name} Ki Apni Zuban Se... 💕</h3>
          <div style="display: flex; flex-direction: column; gap: 10px; margin-top: 8px;">`;
      history.forEach((item, idx) => {
        html += `
            <div style="padding: 10px 12px; background: rgba(255,255,255,0.05); border-radius: 10px;">
              <div style="font-size: 0.75rem; opacity: 0.7; margin-bottom: 4px;">Q${idx+1}: ${item.question || ''}</div>
              <div style="font-size: 0.9rem; color: #ffb3c1; font-style: italic;">"${item.reply || ''}"</div>
            </div>`;
      });
      html += `
          </div>
          <div class="chapter-follow-chat-row">
            <button type="button" class="btn-chapter-follow-chat" data-chapter="Her Words" data-heading="${name} Ki Apni Zuban Se" data-desc="Saved memories from live chat" title="Chat with Her">
              <i class="fa-solid fa-comments"></i> Follow in Chat 💬
            </button>
          </div>
        </div>`;
    }

    chaptersScroll.innerHTML = html;

    // Attach click listeners to all "Follow in Chat" buttons on each chapter
    chaptersScroll.querySelectorAll('.btn-chapter-follow-chat').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();

        const chNum = btn.dataset.chapter || '01';
        const chHeading = btn.dataset.heading || 'Our Journey';
        const chDesc = btn.dataset.desc || '';

        // 1. Pause automated question flow so boyfriend & girlfriend can converse
        isAutomatedChatPaused = true;
        if (btnResumeQuestions) {
          btnResumeQuestions.classList.remove('hidden');
        }

        // 2. Set active WhatsApp-style follow-up quote
        activeFollowUpQuote = {
          chapterNum: chNum,
          heading: chHeading,
          snippet: chDesc
        };

        // 3. Populate and display quote banner
        if (quoteChapterTitle) {
          quoteChapterTitle.textContent = `📖 Chapter ${chNum}: ${chHeading}`;
        }
        if (quoteChapterDesc) {
          quoteChapterDesc.textContent = `"${chDesc.substring(0, 80)}..."`;
        }
        if (chatQuoteBarContainer) {
          chatQuoteBarContainer.classList.remove('hidden');
        }

        // 4. Transition to live chat view
        transitionToRealChat();

        // 5. Unlock user input immediately
        if (chatLiveStatus) chatLiveStatus.textContent = "Live 2-Way Chat Mode 💕";
        if (chatUserInput) {
          chatUserInput.disabled = false;
          chatUserInput.placeholder = `Type your reply or question about "${chHeading}"...`;
          setTimeout(() => chatUserInput.focus(), 300);
        }
        if (chatSendBtn) chatSendBtn.disabled = true;
        if (chatQuickReplies) chatQuickReplies.innerHTML = '';

        // 6. Track recipient activity & send live notification
        trackRecipientActivity('follow_chat_clicked', `Celebrant followed up on "${chHeading}"`, '💬');
      });
    });
  }

  if (bookCardSafarnama) {
    bookCardSafarnama.addEventListener('click', () => {
      trackRecipientActivity('safarnama_opened', 'Opened & Reading Safarnama Journey Book 📖', '📖');
      renderSafarnamaChapters();
      if (modalBookSafarnama) modalBookSafarnama.classList.add('show');
      if (window.birthdayAudio) {
        try { window.birthdayAudio.playGiftOpen(); } catch(e) {}
      }
    });
  }

  if (bookCardMemories) {
    bookCardMemories.addEventListener('click', () => {
      trackRecipientActivity('memories_opened', 'Opened Memories Photo Album 📸', '📸');
    });
  }

  if (closeModalSafarnama) {
    closeModalSafarnama.addEventListener('click', () => {
      if (modalBookSafarnama) modalBookSafarnama.classList.remove('show');
    });
  }

  if (btnSafarnamaToChat) {
    btnSafarnamaToChat.addEventListener('click', () => {
      transitionToRealChat();
    });
  }

  /* =========================================================
     STEP 0: MASTER INDEX & NEON LOGIN & 3D DECK CREATOR LOGIC
     ========================================================= */
  const btnPortalOpenLogin = document.getElementById('btn-portal-open-login');
  const btnPortalViewDemo = document.getElementById('btn-portal-view-demo');
  const portalLoginModal = document.getElementById('portal-login-modal');
  const closeLoginModal = document.getElementById('close-login-modal');
  const portalLoginForm = document.getElementById('portal-login-form');
  const portalRegisterForm = document.getElementById('portal-register-form');
  const loginUsername = document.getElementById('login-username');
  const loginPassword = document.getElementById('login-password');
  const registerUsername = document.getElementById('register-username');
  const registerPassword = document.getElementById('register-password');
  const btnToggleLoginPwd = document.getElementById('btn-toggle-login-pwd');
  const btnToggleRegPwd = document.getElementById('btn-toggle-reg-pwd');
  const btnLoginHelp = document.getElementById('btn-login-help');
  const tabBtnReturning = document.getElementById('tab-btn-returning');
  const tabBtnNew = document.getElementById('tab-btn-new');

  const loggedUserName = document.getElementById('logged-user-name');
  const deckCardGf = document.getElementById('deck-card-gf');
  const deckCardBf = document.getElementById('deck-card-bf');
  const creatorSurpriseForm = document.getElementById('creator-surprise-form');
  const creatorFormHeading = document.getElementById('creator-form-heading');
  const creatorFormSubheading = document.getElementById('creator-form-subheading');
  const creatorInputName = document.getElementById('creator-input-name');
  const creatorInputNickname = document.getElementById('creator-input-nickname');
  const creatorInputAge = document.getElementById('creator-input-age');
  const creatorInputTheme = document.getElementById('creator-input-theme');
  const creatorInputFont = document.getElementById('creator-input-font');
  const creatorInputUpi = document.getElementById('creator-input-upi');
  const inputUpi = document.getElementById('input-upi');

  if (creatorInputUpi) {
    creatorInputUpi.addEventListener('input', () => {
      creatorUpiId = creatorInputUpi.value.trim();
      updateUpiOrderDisplay(creatorUpiId);
      if (currentPortalUser) saveUserFormData(currentPortalUser);
    });
  }

  // Font ID → CSS family string (mirrors scene3d.js getFontFamily)
  function getFontFamilyCss(fontId) {
    const map = {
      'dancing-script': "'Dancing Script', cursive",
      'great-vibes': "'Great Vibes', cursive",
      'cinzel': "'Cinzel', serif",
      'playfair': "'Playfair Display', serif",
      'outfit': "'Outfit', sans-serif",
      'pacifico': "'Pacifico', cursive",
      'parisienne': "'Parisienne', cursive",
      'alex-brush': "'Alex Brush', cursive",
      'sacramento': "'Sacramento', cursive",
      'marcellus': "'Marcellus', serif",
      'montserrat': "'Montserrat', sans-serif",
      'press-start': "'Press Start 2P', monospace"
    };
    return map[fontId] || "'Outfit', sans-serif";
  }

  // Font ID → human-readable description
  function getFontDesc(fontId) {
    const desc = {
      'outfit': 'Outfit — Modern Bold Luxury',
      'dancing-script': 'Dancing Script — Romantic Calligraphy',
      'great-vibes': 'Great Vibes — Royal Signature',
      'cinzel': 'Cinzel — Imperial Palace Gold',
      'playfair': 'Playfair Display — Vintage Serif',
      'pacifico': 'Pacifico — Sweet Heart Brush',
      'parisienne': 'Parisienne — French Romance',
      'alex-brush': 'Alex Brush — Princess Script',
      'sacramento': 'Sacramento — Delicate Love Letter',
      'marcellus': 'Marcellus — Heritage Roman',
      'montserrat': 'Montserrat — Ultra Bold Elegant',
      'press-start': 'Press Start 2P — Retro 8-Bit'
    };
    return desc[fontId] || 'Outfit — Modern Bold Luxury';
  }

  // Update live preview card when font or name changes (restored original behavior)
  function updateFontLivePreview() {
    const sample = document.getElementById('font-live-preview-sample');
    const descEl = document.getElementById('font-live-preview-desc');
    if (!sample) return;
    const nameText = (creatorInputName && creatorInputName.value.trim()) || 'MY LOVE';
    sample.textContent = nameText.toUpperCase();
    sample.style.fontFamily = getFontFamilyCss(celebrantFont);
    if (descEl) descEl.textContent = getFontDesc(celebrantFont);
  }

  // Update preview live as celebrant name is typed
  if (creatorInputName) {
    creatorInputName.addEventListener('input', () => {
      updateFontLivePreview();
    });
  }

  // Custom Font Dropdown logic
  const fontCustomSelect = document.getElementById('font-custom-select');
  const fontCustomTrigger = document.getElementById('font-custom-trigger');
  const fontTriggerEmoji = document.getElementById('font-trigger-emoji');
  const fontTriggerText = document.getElementById('font-trigger-text');

  function setCustomFontSelection(fontId) {
    if (!fontId) return;
    celebrantFont = fontId;
    if (creatorInputFont) creatorInputFont.value = fontId;
    
    // Find matching option in custom dropdown
    const option = document.querySelector(`.font-option[data-value="${fontId}"]`);
    if (option) {
      document.querySelectorAll('.font-option').forEach(el => el.classList.remove('selected'));
      option.classList.add('selected');
      const emoji = option.getAttribute('data-emoji') || '💎';
      const name = option.getAttribute('data-name') || 'Outfit';
      const sample = option.getAttribute('data-sample') || name;
      const family = option.getAttribute('data-family') || "'Outfit', sans-serif";
      if (fontTriggerEmoji) fontTriggerEmoji.textContent = emoji;
      if (fontTriggerText) {
        fontTriggerText.innerHTML = `${name} (<span class="font-trigger-sample" style="font-family:${family};">${sample}</span>)`;
      }
    }
    updateFontLivePreview();
    // Live update 3D scene
    if (scene && scene.updateCelebrantInfo3D) {
      scene.updateCelebrantInfo3D(
        creatorInputName ? creatorInputName.value.trim() || 'My Love' : 'My Love',
        creatorInputAge ? creatorInputAge.value : '',
        celebrantFont
      );
    }
  }

  if (fontCustomTrigger && fontCustomSelect) {
    fontCustomTrigger.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = fontCustomSelect.classList.toggle('open');
      fontCustomTrigger.setAttribute('aria-expanded', isOpen);
    });

    document.querySelectorAll('.font-option').forEach(opt => {
      opt.addEventListener('click', (e) => {
        e.stopPropagation();
        const val = opt.getAttribute('data-value');
        setCustomFontSelection(val);
        fontCustomSelect.classList.remove('open');
        fontCustomTrigger.setAttribute('aria-expanded', 'false');
      });
    });

    document.addEventListener('click', (e) => {
      if (!fontCustomSelect.contains(e.target)) {
        fontCustomSelect.classList.remove('open');
        fontCustomTrigger.setAttribute('aria-expanded', 'false');
      }
    });
  }

  if (creatorInputFont) {
    creatorInputFont.addEventListener('change', () => {
      setCustomFontSelection(creatorInputFont.value || 'outfit');
    });
  }

  const creatorInputWish = document.getElementById('creator-input-wish');
  const creatorInputPhoto = document.getElementById('creator-input-photo');
  const creatorPhotoStatus = document.getElementById('creator-photo-status');
  const creatorInputPhotoUrl = document.getElementById('creator-input-photo-url');
  const generatedLinkBox = document.getElementById('generated-link-box');
  const finalSurpriseLinkInput = document.getElementById('final-surprise-link-input');
  const btnCopyFinalLink = document.getElementById('btn-copy-final-link');
  const finalCopyFeedback = document.getElementById('final-copy-feedback');
  const btnLaunchPreview = document.getElementById('btn-launch-preview');
  const btnLogoutPortal = document.getElementById('btn-logout-portal');

  // 1. Landing Screen CTAs
  if (btnPortalOpenLogin) {
    btnPortalOpenLogin.addEventListener('click', () => {
      if (portalLoginModal) portalLoginModal.classList.add('show');
      if (loginUsername) loginUsername.focus();
    });
  }

  if (closeLoginModal) {
    closeLoginModal.addEventListener('click', () => {
      if (portalLoginModal) portalLoginModal.classList.remove('show');
    });
  }

  const btnBackToHome = document.getElementById('btn-back-to-home');

  // Helper: show / hide the floating back button (only in guest/preview mode)
  function showPreviewBackBtn() {
    if (btnBackToHome) btnBackToHome.classList.remove('hidden');
  }
  function hidePreviewBackBtn() {
    if (btnBackToHome) btnBackToHome.classList.add('hidden');
  }

  // Back button click → return to landing screen
  if (btnBackToHome) {
    btnBackToHome.addEventListener('click', () => {
      // Show landing screen again
      if (portalLandingScreen) portalLandingScreen.classList.remove('hidden');
      // Hide creator dashboard if open
      if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      // Hide curtain container if visible
      if (curtainContainer) {
        curtainContainer.style.display = 'none';
        curtainContainer.classList.remove('opened');
      }
      // Scroll to top smoothly
      window.scrollTo({ top: 0, behavior: 'smooth' });
      // Hide the back button itself
      hidePreviewBackBtn();
    });
  }

  if (btnPortalViewDemo) {
    btnPortalViewDemo.addEventListener('click', () => {
      if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
      if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      if (curtainContainer) {
        curtainContainer.style.display = 'flex';
        curtainContainer.classList.remove('opened');
      }
      // Show back button so user can return from preview
      showPreviewBackBtn();
      if (window.birthdayAudio) {
        try { window.birthdayAudio.playFanfare(); } catch(e) {}
      }
    });
  }


  // 2. Toggle Login Password Visibility
  if (btnToggleLoginPwd && loginPassword) {
    btnToggleLoginPwd.addEventListener('click', () => {
      const isPwd = loginPassword.type === 'password';
      loginPassword.type = isPwd ? 'text' : 'password';
      btnToggleLoginPwd.innerHTML = isPwd ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
    });
  }

  // 3. Help Button
  if (btnLoginHelp) {
    btnLoginHelp.addEventListener('click', () => {
      alert("💡 PORTAL & PASSWORD HELP:\n\n• Aapka username & password aapke browser & Telegram bot me secure save hota hai.\n• NOTE: Agar password bhool gaye to access recover nahi hoga, isliye apna password hamesha yaad rakhein!\n• Har baar isi password se authenticate karke aap apni surprise settings edit ya generate kar sakte hain. 💕");
    });
  }

  // --- Security helpers ---

  // Retrieve the session token from localStorage (survives page reload).
  function getSessionToken() {
    try {
      return localStorage.getItem('birthday_api_session_token') || apiAuthToken || null;
    } catch(e) { return null; }
  }

  // Build an API header set that carries the session token for any
  // authenticated endpoint. Public endpoints (status, get_surprise,
  // photo) use this only when a token is present.
  function authHeaders(extra) {
    const token = getSessionToken();
    const headers = Object.assign({ 'Content-Type': 'application/json' }, extra || {});
    if (token) headers['Authorization'] = 'Bearer ' + token;
    return headers;
  }

  // --- Helper: Save current form data to localStorage keyed by username ---
  function saveUserFormData(userKey) {
    if (!userKey) return;
    const data = {
      name: creatorInputName ? creatorInputName.value : '',
      nickname: creatorInputNickname ? creatorInputNickname.value : '',
      age: creatorInputAge ? creatorInputAge.value : '',
      theme: creatorInputTheme ? creatorInputTheme.value : 'rose-glamour',
      font: creatorInputFont ? creatorInputFont.value : celebrantFont,
      wish: creatorInputWish ? creatorInputWish.value : '',
      photoUrl: creatorInputPhotoUrl ? creatorInputPhotoUrl.value : '',
      upi: (creatorInputUpi && creatorInputUpi.value.trim()) || creatorUpiId || '',
      mode: selectedCreatorMode,
      safarnama: userSafarnamaChapters,
      questions: userCustomQuestions,
      memoriesPhotos: userMemoriesPhotos,
      savedAt: new Date().toISOString()
    };
    try {
      localStorage.setItem(`birthday_userdata_${userKey}`, JSON.stringify(data));
      localStorage.setItem(`birthday_safarnama_${userKey}`, JSON.stringify(userSafarnamaChapters));
      localStorage.setItem(`birthday_questions_${userKey}`, JSON.stringify(userCustomQuestions));
      localStorage.setItem(`birthday_memories_photos_${userKey}`, JSON.stringify(userMemoriesPhotos));
    } catch(e) {}
    // Also try server
       try {
       fetch(`${API_BASE}/api/save_user_data`, {
         method: 'POST',
         headers: authHeaders(),
         body: JSON.stringify({ username: userKey, user_data: data })
       }).catch(() => {});
     } catch(e) {}
  }

  // --- Helper: Apply restored form data to UI ---
  function applyRestoredFormData(data) {
    if (!data) return;
    if (creatorInputName && data.name) creatorInputName.value = data.name;
    if (creatorInputNickname && data.nickname) creatorInputNickname.value = data.nickname;
    if (creatorInputAge && data.age) creatorInputAge.value = data.age;
    if (creatorInputTheme && data.theme) creatorInputTheme.value = data.theme;
    if (data.font) {
      if (typeof setCustomFontSelection === 'function') {
        setCustomFontSelection(data.font);
      } else {
        celebrantFont = data.font;
        if (creatorInputFont) creatorInputFont.value = data.font;
        updateFontLivePreview();
      }
    }
    if (creatorInputWish && data.wish) creatorInputWish.value = data.wish;
    if (creatorInputPhotoUrl && data.photoUrl) {
      creatorInputPhotoUrl.value = data.photoUrl;
    }
    if (data.upi) {
      updateUpiOrderDisplay(data.upi);
    }
    if (data.photoUrl) {
      currentPhotoDataUrl = data.photoUrl;
      const singlePreview = document.getElementById('creator-single-photo-preview');
      const previewImg = document.getElementById('main-photo-preview-img');
      const photoTick = document.getElementById('main-photo-tick');
      if (singlePreview && previewImg) {
        previewImg.src = data.photoUrl;
        singlePreview.classList.remove('hidden');
      }
      if (photoTick) {
        photoTick.classList.remove('hidden');
      }
      if (creatorPhotoStatus) {
        creatorPhotoStatus.textContent = '✅ Photo loaded from Telegram Cloud!';
        creatorPhotoStatus.style.color = '#00ff88';
      }
    }
    if (data.mode) {
      if (typeof setModeCard === 'function') setModeCard(data.mode);
      else setDeckMode(data.mode);
    }

    if (data.safarnama && Array.isArray(data.safarnama) && data.safarnama.length > 0) {
      userSafarnamaChapters = data.safarnama;
    }

    if (data.questions && Array.isArray(data.questions) && data.questions.length > 0) {
      userCustomQuestions = data.questions;
    }

    if (data.memoriesPhotos && Array.isArray(data.memoriesPhotos) && data.memoriesPhotos.length > 0) {
      userMemoriesPhotos = data.memoriesPhotos;
      renderMemoriesPreviewsGrid();
    }

    // Merge and render all photos across modals & scene
    updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);

    // Apply restored theme & name
    if (data.theme) applyTheme(data.theme);
    if (data.name) {
      celebrantName = data.name;
      celebrantAge = data.age || '';
      customWish = data.wish || customWish;
      updateCelebrantInfo();
    }
    if (data.photoUrl) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => { if (scene) scene.updateUserPhoto(img); };
      img.src = data.photoUrl;
    }
    renderSafarnamaBuilder();
    if (typeof renderQuestionsBuilder === 'function') renderQuestionsBuilder();
    if (typeof updateWizardValidation === 'function') updateWizardValidation();
  }

  // --- Helper: Restore saved form data (Server-First with Local Cache Fallback) ---
  function restoreUserFormData(userKey) {
    if (!userKey) return;

    // 1. Instant local render (if cached in this browser)
    let local = null;
    try {
      const localStr = localStorage.getItem(`birthday_userdata_${userKey}`);
      if (localStr) local = JSON.parse(localStr);
    } catch(e) {}
    if (local) {
      applyRestoredFormData(local);
    }

    // 2. Fetch live data from Backend / Telegram Cloud (survives any device/browser switch)
    fetch(`${API_BASE}/api/get_user_data?username=${encodeURIComponent(userKey)}`, {
      method: 'GET',
      headers: authHeaders()
    })
    .then(res => res.json())
    .then(json => {
      if (json.status === 'success' && json.user_data && Object.keys(json.user_data).length > 0) {
        applyRestoredFormData(json.user_data);
        try {
          localStorage.setItem(`birthday_userdata_${userKey}`, JSON.stringify(json.user_data));
        } catch(e) {}
      }
    })
    .catch(() => {});
  }

  // Removes any surprise-link/preview/demo query params from the URL so a
  // stale link param doesn't force the 3D curtain open over login/logout/
  // dashboard routing. Keeps the same page, just cleans the query string.
  function clearSurpriseLinkParamsFromUrl() {
    try {
      const url = new URL(window.location.href);
      ['s', 'surprise', 'name', 'preview', 'demo', 'exp', 'u', 'safarnama'].forEach(p => url.searchParams.delete(p));
      if (window.location.hash) url.hash = '';
      window.history.replaceState({}, document.title, url.pathname + (url.search ? url.search : ''));
    } catch(e) {}
  }

  // --- Helper: Open dashboard after successful login/register ---
  function openDashboardForUser(uName) {
    // A fresh login/register is always the CREATOR opening their dashboard,
    // never a recipient viewing a surprise link — strip any leftover
    // surprise-link params (?s=, ?preview=, etc.) so the 3D curtain route
    // doesn't hijack the view on this load or the next page refresh.
    clearSurpriseLinkParamsFromUrl();
    if (curtainContainer) {
      curtainContainer.style.display = 'none';
      curtainContainer.classList.remove('opened');
    }
    document.documentElement.classList.add('route-creator-dashboard');
    document.documentElement.classList.remove('route-surprise-curtain', 'route-portal-landing');

    currentPortalUser = uName.toLowerCase();
    if (loggedUserName) loggedUserName.textContent = uName;
    if (portalLoginModal) portalLoginModal.classList.remove('show');
    if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
    if (portalCreatorDashboard) portalCreatorDashboard.classList.remove('hidden');

    // Restore previous form data & render Safarnama builder
    restoreUserFormData(currentPortalUser);
    initCreatorLiveTracker();

    // Direct landing to Step 4 if active unexpired link already exists
    const savedExp = localStorage.getItem(`birthday_link_expires_${currentPortalUser}`);
    const lastLink = localStorage.getItem(`birthday_last_generated_link_${currentPortalUser}`);
    if (savedExp) {
      const expNum = parseInt(savedExp, 10);
      if (Date.now() < expNum && lastLink) {
        if (finalSurpriseLinkInput) finalSurpriseLinkInput.value = lastLink;
        if (generatedLinkBox) generatedLinkBox.classList.remove('hidden');
        startLinkExpiryCountdown(expNum, currentPortalUser);
        goToWizardStep(4);
      } else {
        goToWizardStep(1);
      }
    } else {
      goToWizardStep(1);
    }

    if (window.confetti) window.confetti({ particleCount: 50, spread: 70, origin: { y: 0.6 } });
    if (window.birthdayAudio) { try { window.birthdayAudio.playFanfare(); } catch(e) {} }
  }

  // --- Login Tab Switcher ---
  if (tabBtnReturning && tabBtnNew) {
    [tabBtnReturning, tabBtnNew].forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.getAttribute('data-tab');
        [tabBtnReturning, tabBtnNew].forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.querySelectorAll('.login-tab-content').forEach(c => {
          c.classList.toggle('active', c.getAttribute('data-tab') === tab);
        });
      });
    });
  }

  // 1. Landing Screen CTAs
  if (btnPortalOpenLogin) {
    btnPortalOpenLogin.addEventListener('click', () => {
      if (portalLoginModal) portalLoginModal.classList.add('show');
      if (loginUsername) loginUsername.focus();
    });
  }

  if (closeLoginModal) {
    closeLoginModal.addEventListener('click', () => {
      if (portalLoginModal) portalLoginModal.classList.remove('show');
    });
  }

  if (btnPortalViewDemo) {
    btnPortalViewDemo.addEventListener('click', () => {
      if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
      if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      if (window.birthdayAudio) { try { window.birthdayAudio.playFanfare(); } catch(e) {} }
    });
  }

  // 2. Toggle Password Visibility
  if (btnToggleLoginPwd && loginPassword) {
    btnToggleLoginPwd.addEventListener('click', () => {
      const isPwd = loginPassword.type === 'password';
      loginPassword.type = isPwd ? 'text' : 'password';
      btnToggleLoginPwd.innerHTML = isPwd ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
    });
  }

  if (btnToggleRegPwd && registerPassword) {
    btnToggleRegPwd.addEventListener('click', () => {
      const isPwd = registerPassword.type === 'password';
      registerPassword.type = isPwd ? 'text' : 'password';
      btnToggleRegPwd.innerHTML = isPwd ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
    });
  }

  // 3. Help Button
  if (btnLoginHelp) {
    btnLoginHelp.addEventListener('click', () => {
      alert('💡 PORTAL HELP:\n\n• Returning User: Enter your username & password to login and restore your saved data.\n• New User: Create a new account — remember your password, there is no recovery!\n\nAap Delete Account option se apna data permanently delete kar sakte hain. 💕');
    });
  }

  // Helper: Sync registered/logging-in user credentials with Telegram Bot
  async function syncUserCredentialsWithBot(uName, pwd, action) {
    if (!uName) return { success: false, message: 'Username required' };
    try {
      const res = await fetch(`${API_BASE}/api/sync_portal_user`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: uName.toLowerCase().trim(), password: pwd, action: action })
      });
      const json = await res.json();
      return { success: res.ok && json.status === 'success', message: json.message };
    } catch(e) {
      return { success: false, message: e.message };
    }
  }

  // Authenticate the user with the API and store a session token.
  // POST /api/auth returns { status, token } on success.
  async function authenticatePortalUser(uName, pwd) {
    if (!uName || !pwd) return { success: false, message: 'Username and password required' };
    try {
      const res = await fetch(`${API_BASE}/api/auth`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: uName.toLowerCase().trim(), password: pwd })
      });
      const json = await res.json();
      if (res.ok && json.status === 'success' && json.token) {
        apiAuthToken = json.token;
        try { localStorage.setItem('birthday_api_session_token', json.token); } catch(e) {}
        return { success: true, token: json.token };
      } else {
        return { success: false, message: json.message || 'Invalid credentials' };
      }
    } catch(err) {
      return { success: false, message: 'Server connection error: ' + err.message };
    }
  }

  // Clear the session token on logout / delete.
  function clearSessionToken() {
    apiAuthToken = null;
    try { localStorage.removeItem('birthday_api_session_token'); } catch(e) {}
  }

  // 4. RETURNING USER Login Form (Direct Server Authentication)
  if (portalLoginForm) {
    portalLoginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const uName = (loginUsername ? loginUsername.value.trim() : '') || 'Boyfriend';
      const pwd = loginPassword ? loginPassword.value : '';

      if (!uName || !pwd) { alert('Please enter both username and password!'); return; }

      const submitBtn = document.getElementById('btn-login-start');
      const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Authenticating with Telegram Cloud...';
      }

      try {
        // Direct Server Authentication (No browser localStorage blocker!)
        const authRes = await authenticatePortalUser(uName, pwd);
        if (authRes.success) {
          try { localStorage.setItem('birthday_portal_session', uName); } catch(err) {}
          openDashboardForUser(uName);
        } else {
          // If server returned invalid credentials or user not found
          alert(`❌ Login Failed: ${authRes.message}\n\nAgar aap naye user hain, to kripya "New User" tab se account banayein.`);
        }
      } catch(err) {
        alert('Server connection error: ' + err.message);
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = origBtnHtml;
        }
      }
    });
  }

  // 5. NEW USER Registration Form (Server-First Sync & Auth)
  if (portalRegisterForm) {
    portalRegisterForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const uName = (registerUsername ? registerUsername.value.trim() : '') || 'Boyfriend';
      const pwd = registerPassword ? registerPassword.value : '';

      if (!uName || !pwd) { alert('Please enter both username and password!'); return; }
      if (pwd.length < 4) { alert('⚠️ Password must be at least 4 characters!'); return; }

      const submitBtn = document.getElementById('btn-register-start');
      const origBtnHtml = submitBtn ? submitBtn.innerHTML : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Creating Account on Telegram Cloud...';
      }

      try {
        // 1. Sync & register user on backend / Telegram cloud first
        const syncRes = await syncUserCredentialsWithBot(uName, pwd, 'register');
        if (!syncRes.success) {
          alert('❌ Registration failed: ' + (syncRes.message || 'Could not register user'));
          return;
        }

        // 2. Immediately authenticate and obtain session token
        const authRes = await authenticatePortalUser(uName, pwd);
        if (authRes.success) {
          try { localStorage.setItem('birthday_portal_session', uName); } catch(err) {}
          openDashboardForUser(uName);
        } else {
          alert('Account created, but login error: ' + authRes.message);
        }
      } catch(err) {
        alert('Error connecting to Telegram Bot API: ' + err.message);
      } finally {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = origBtnHtml;
        }
      }
    });
  }

  // ===== 5-MODE SURPRISE CAROUSEL CONTROLLER =====
  const MODE_CONFIGS = {
    gf: {
      heading: "💖 Fill Her Surprise Details",
      subheading: "Personalize her name, romantic wish, and upload photo:",
      namePlaceholder: "e.g. Ananya / Priya / Jaan",
      nickPlaceholder: "e.g. My Princess / Angel / Queen",
      theme: "rose-glamour",
      wish: "Happy Birthday to the most amazing, gorgeous, and loving girl in the whole world! Thank you for bringing endless joy, warmth, and magic into my life. Every single day with you is my favorite day. May all your sweetest dreams come true today and forever! 💖✨"
    },
    bf: {
      heading: "👦 Fill His Surprise Details",
      subheading: "Personalize his name, sweet wish, and upload photo:",
      namePlaceholder: "e.g. Rahul / Aryan / Kabir",
      nickPlaceholder: "e.g. My Handsome King / Rockstar / Hero",
      theme: "midnight-gold",
      wish: "Happy Birthday to the most loving, wonderful, and caring boyfriend in the world! Thank you for always protecting me, making me laugh, and being my biggest support. I love you to infinity and beyond! 🤴🔥"
    },
    friend: {
      heading: "🤝 Fill Your Bestie's Surprise Details",
      subheading: "Personalize their name, fun wish, and upload photo:",
      namePlaceholder: "e.g. Rohit / Sneha / Aman",
      nickPlaceholder: "e.g. Partner in Crime / Bro / Bestie",
      theme: "cyber-neon",
      wish: "Happy Birthday to my absolute favorite human & partner in crime! 🥳 Thank you for all the endless laughs, crazy memories, and late-night gossips. May this year bring you massive success, happiness, and free treats for me! 🎉🍕"
    },
    spouse: {
      heading: "💍 Fill Your Beloved's Surprise Details",
      subheading: "Personalize their name, heartfelt life-partner wish, and upload photo:",
      namePlaceholder: "e.g. Simran / Vikram / Shweta",
      nickPlaceholder: "e.g. My Life / Soulmate / Humsafar",
      theme: "rose-glamour",
      wish: "Happy Birthday to my beloved life partner & soulmate! ❤️ Walking through life hand in hand with you is the greatest blessing I could ever ask for. Thank you for making our home a paradise filled with peace, laughter, and unconditional love. Forever yours! 💍✨"
    },
    boss: {
      heading: "👔 Fill Your Leader's Surprise Details",
      subheading: "Personalize their name, inspiring wish, and upload photo:",
      namePlaceholder: "e.g. Sir / Ma'am / Mr. Sharma",
      nickPlaceholder: "e.g. Our Respected Mentor / Leader / Guide",
      theme: "midnight-gold",
      wish: "Warmest Birthday greetings to an inspiring leader and incredible mentor! 🌟 Thank you for your visionary leadership, invaluable guidance, and constant encouragement. Wishing you continued success, good health, and prosperous milestones ahead! 👔⭐"
    }
  };

  const MODE_ORDER = ['gf', 'bf', 'friend', 'spouse', 'boss'];
  let currentModeIdx = 0;

  function setModeCard(mode) {
    if (!MODE_CONFIGS[mode]) mode = 'gf';
    selectedCreatorMode = mode;
    currentModeIdx = MODE_ORDER.indexOf(mode);

    // Update active card class & badge
    MODE_ORDER.forEach(m => {
      const card = document.getElementById(`mode-card-${m}`);
      if (card) {
        const isActive = (m === mode);
        card.classList.toggle('mode-card-active', isActive);
        const badge = card.querySelector('.mode-card-badge');
        if (badge) {
          badge.innerHTML = isActive
            ? '<i class="fa-solid fa-circle-check"></i> SELECTED'
            : '<i class="fa-solid fa-hand-pointer"></i> Tap to Select';
        }
      }
    });

    // Update carousel dots
    document.querySelectorAll('.carousel-dot').forEach((dot, idx) => {
      dot.classList.toggle('active', idx === currentModeIdx);
    });

    // Update form labels & placeholders
    const cfg = MODE_CONFIGS[mode];
    if (creatorFormHeading) creatorFormHeading.textContent = cfg.heading;
    if (creatorFormSubheading) creatorFormSubheading.textContent = cfg.subheading;
    if (creatorInputName) creatorInputName.placeholder = cfg.namePlaceholder;
    if (creatorInputNickname) creatorInputNickname.placeholder = cfg.nickPlaceholder;
    if (creatorInputTheme && cfg.theme) creatorInputTheme.value = cfg.theme;
    if (creatorInputWish && (!creatorInputWish.value || Object.values(MODE_CONFIGS).some(c => c.wish === creatorInputWish.value))) {
      creatorInputWish.value = cfg.wish;
    }

    if (window.birthdayAudio) {
      try { window.birthdayAudio.playPop(); } catch(e) {}
    }

    if (typeof updateWizardValidation === 'function') updateWizardValidation();
  }

  function setDeckMode(mode) {
    setModeCard(mode);
  }

  function scrollModeCardIntoView(idx) {
    const targetMode = MODE_ORDER[idx];
    const targetCard = document.getElementById(`mode-card-${targetMode}`);
    if (targetCard) {
      targetCard.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
    }
  }

  // Arrow navigation buttons on card borders
  const modeArrowLeft = document.getElementById('mode-arrow-left');
  const modeArrowRight = document.getElementById('mode-arrow-right');

  if (modeArrowLeft) {
    modeArrowLeft.addEventListener('click', () => {
      currentModeIdx = (currentModeIdx - 1 + MODE_ORDER.length) % MODE_ORDER.length;
      setModeCard(MODE_ORDER[currentModeIdx]);
      scrollModeCardIntoView(currentModeIdx);
    });
  }

  if (modeArrowRight) {
    modeArrowRight.addEventListener('click', () => {
      currentModeIdx = (currentModeIdx + 1) % MODE_ORDER.length;
      setModeCard(MODE_ORDER[currentModeIdx]);
      scrollModeCardIntoView(currentModeIdx);
    });
  }

  // Card clicks
  MODE_ORDER.forEach((m, idx) => {
    const card = document.getElementById(`mode-card-${m}`);
    if (card) {
      card.addEventListener('click', () => {
        setModeCard(m);
        scrollModeCardIntoView(idx);
      });
    }
  });

  // Dots clicks
  document.querySelectorAll('.carousel-dot').forEach((dot) => {
    dot.addEventListener('click', (e) => {
      const idx = parseInt(e.currentTarget.getAttribute('data-idx'), 10);
      if (!isNaN(idx) && MODE_ORDER[idx]) {
        setModeCard(MODE_ORDER[idx]);
        scrollModeCardIntoView(idx);
      }
    });
  });

  // Real Photo Upload Progress Bar Helper
  function updateMainPhotoProgress(percent) {
    const wrap = document.getElementById('main-photo-progress-wrap');
    const fill = document.getElementById('main-photo-progress-fill');
    const txt = document.getElementById('main-photo-progress-text');
    if (wrap) wrap.classList.remove('hidden');
    if (fill) fill.style.width = `${percent}%`;
    if (txt) txt.textContent = `${percent}%`;
    if (percent >= 100) {
      setTimeout(() => {
        if (wrap) wrap.classList.add('hidden');
      }, 700);
    }
  }

  // Helper: Set and preview main portrait photo
  function setMainPortraitPhoto(url, statusMsg = '✅ Photo Ready!') {
    if (!url) return;
    currentPhotoDataUrl = url; // store raw (relative proxy stays portable)
    if (creatorInputPhotoUrl && (url.startsWith('http') || url.startsWith('/api/photo'))) {
      creatorInputPhotoUrl.value = url.startsWith('/api/') ? (API_BASE + url) : url;
    }
    const singlePreview = document.getElementById('creator-single-photo-preview');
    const previewImg = document.getElementById('main-photo-preview-img');
    const photoTick = document.getElementById('main-photo-tick');
    if (singlePreview && previewImg) {
      previewImg.src = resolvePhotoUrl(url);
      singlePreview.classList.remove('hidden');
    }
    if (photoTick) {
      photoTick.classList.remove('hidden');
    }
    if (creatorPhotoStatus) {
      creatorPhotoStatus.textContent = statusMsg;
      creatorPhotoStatus.style.color = '#00ff88';
    }
    updateMemoriesPhoto(url, userMemoriesPhotos);
    if (currentPortalUser) saveUserFormData(currentPortalUser);
    if (typeof updateWizardValidation === 'function') updateWizardValidation();
  }

  // 6. Main Portrait Photo Upload (Lossless upload to local server API + Instant Preview + Real Progress + Green Tick)
  if (creatorInputPhoto) {
    creatorInputPhoto.addEventListener('change', (e) => {
      const file = e.target.files[0];
      if (!file) return;

      if (creatorPhotoStatus) {
        creatorPhotoStatus.textContent = '⏳ Uploading Photo...';
        creatorPhotoStatus.style.color = '#ffd700';
      }

      updateMainPhotoProgress(20);

      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target.result;
        updateMainPhotoProgress(60);
        // Show local preview immediately
        setMainPortraitPhoto(dataUrl, '⏳ Uploading to Server...');

        // Upload original lossless file to server & Telegram Cloud
        fetch(`${API_BASE}/api/upload_image`, {
          method: 'POST',
          headers: authHeaders(),
          body: JSON.stringify({
            image: dataUrl,
            filename: file.name,
            username: currentPortalUser || 'user',
            type: 'Main Portrait'
          })
        })
        .then(res => res.json())
        .then(serverData => {
          updateMainPhotoProgress(100);
          if (serverData && serverData.status === 'success' && serverData.url) {
            const finalPhotoUrl = serverData.tg_url || serverData.url;
            setMainPortraitPhoto(finalPhotoUrl, '✅ Photo Uploaded to Telegram & Saved!');
            setMainPortraitPhoto(dataUrl, '✅ Photo Ready!');
          }
        })
        .catch(() => {
          updateMainPhotoProgress(100);
          setMainPortraitPhoto(dataUrl, '✅ Photo Ready!');
        });
      };
      reader.readAsDataURL(file);
    });
  }

  // Main photo thumbnail lightbox click
  const mainPhotoPreviewImg = document.getElementById('main-photo-preview-img');
  if (mainPhotoPreviewImg) {
    mainPhotoPreviewImg.addEventListener('click', () => {
      const src = currentPhotoDataUrl || mainPhotoPreviewImg.src;
      if (src) openMemoryLightbox(src);
    });
  }

  // Main photo thumbnail remove button
  const btnRemoveMainPhoto = document.getElementById('btn-remove-main-photo');
  if (btnRemoveMainPhoto) {
    btnRemoveMainPhoto.addEventListener('click', (e) => {
      e.stopPropagation();
      if (creatorInputPhoto) creatorInputPhoto.value = '';
      if (creatorInputPhotoUrl) creatorInputPhotoUrl.value = '';
      currentPhotoDataUrl = null;
      const singlePreview = document.getElementById('creator-single-photo-preview');
      if (singlePreview) singlePreview.classList.add('hidden');
      const photoTick = document.getElementById('main-photo-tick');
      if (photoTick) photoTick.classList.add('hidden');
      const wrap = document.getElementById('main-photo-progress-wrap');
      if (wrap) wrap.classList.add('hidden');
      if (creatorPhotoStatus) {
        creatorPhotoStatus.textContent = 'No photo selected';
        creatorPhotoStatus.style.color = 'rgba(255,255,255,0.7)';
      }
      updateMemoriesPhoto(null, userMemoriesPhotos);
      if (currentPortalUser) saveUserFormData(currentPortalUser);
      if (typeof updateWizardValidation === 'function') updateWizardValidation();
    });
  }

  if (creatorInputPhotoUrl) {
    creatorInputPhotoUrl.addEventListener('input', () => {
      const url = creatorInputPhotoUrl.value.trim();
      if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
        setMainPortraitPhoto(url, '✅ Photo URL Loaded!');
      }
    });
  }

  // --- Memories Album Multiple Photo Uploader Handlers ---
  const creatorInputMemoriesPhotos = document.getElementById('creator-input-memories-photos');
  const memoriesPhotosStatus = document.getElementById('memories-photos-status');
  const creatorInputMemoryUrlSingle = document.getElementById('creator-input-memory-url-single');
  const btnAddMemoryUrl = document.getElementById('btn-add-memory-url');
  const memoriesPreviewsGrid = document.getElementById('memories-previews-grid');

  function renderMemoriesPreviewsGrid() {
    const grid = document.getElementById('memories-previews-grid');
    const statusEl = document.getElementById('memories-photos-status');
    if (!grid) return;

    if (!userMemoriesPhotos || userMemoriesPhotos.length === 0) {
      grid.innerHTML = `
        <div style="font-size: 0.82rem; color: rgba(255,255,255,0.55); font-style: italic; width: 100%;">
          No custom photos added yet. Default sample polaroids will be shown.
        </div>
      `;
      if (statusEl) {
        statusEl.textContent = '0 Custom Photos Added';
        statusEl.style.color = '#ffcbd5';
      }
      return;
    }

    if (statusEl) {
      statusEl.textContent = `✅ ${userMemoriesPhotos.length} Custom Photo${userMemoriesPhotos.length > 1 ? 's' : ''} Added!`;
      statusEl.style.color = '#00ff88';
    }

    let html = '';
    userMemoriesPhotos.forEach((photo, idx) => {
      const rawSrc = typeof photo === 'object' ? (photo.cdnUrl || photo.localUrl || '') : photo;
      const src = resolvePhotoUrl(rawSrc);
      const isUploading = typeof photo === 'object' && photo.uploading;
      html += `
        <div class="memory-thumb-chip" data-idx="${idx}" style="cursor:pointer;" title="Click to view full image">
          <img src="${src}" alt="Memory ${idx + 1}" class="memory-thumb-img">
          <button type="button" class="btn-remove-thumb" data-idx="${idx}" title="Remove">&times;</button>
          ${isUploading ? '<div class="thumb-upload-indicator">⏳ Uploading...</div>' : '<div class="photo-upload-tick" style="position:absolute; bottom:4px; right:4px; font-size:0.72rem; padding:2px 6px; z-index:5;"><i class="fa-solid fa-circle-check"></i></div>'}
        </div>
      `;
    });
    grid.innerHTML = html;

    // Lightbox click on thumbnail
    grid.querySelectorAll('.memory-thumb-img').forEach((imgEl, idx) => {
      imgEl.addEventListener('click', () => {
        const photo = userMemoriesPhotos[idx];
        const src = typeof photo === 'object' ? (photo.cdnUrl || photo.localUrl || '') : photo;
        if (src) openMemoryLightbox(src);
      });
    });

    // Remove click on thumbnail
    grid.querySelectorAll('.btn-remove-thumb').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idxToRemove = parseInt(e.currentTarget.getAttribute('data-idx'), 10);
        if (!isNaN(idxToRemove)) {
          userMemoriesPhotos.splice(idxToRemove, 1);
          renderMemoriesPreviewsGrid();
          updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);
          if (currentPortalUser) saveUserFormData(currentPortalUser);
        }
      });
    });
  }

  // Upload a single memory file — show FileReader dataURL preview INSTANTLY & upload to server
  function uploadMemoryFile(file, onDone) {
    const photoEntry = { localUrl: null, cdnUrl: null, uploading: true };

    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target.result;
      photoEntry.localUrl = dataUrl; // instant local preview
      userMemoriesPhotos.push(photoEntry);
      renderMemoriesPreviewsGrid();
      updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);
      if (currentPortalUser) saveUserFormData(currentPortalUser);

       // Attempt 1: Upload to local server API & Telegram Cloud (lossless, original resolution)
       fetch(`${API_BASE}/api/upload_image`, {
         method: 'POST',
         headers: authHeaders(),
         body: JSON.stringify({
           image: dataUrl,
           filename: file.name,
           username: currentPortalUser || 'user',
           type: 'Memories Album'
        })
      })
      .then(res => res.json())
      .then(serverData => {
        if (serverData && serverData.status === 'success' && serverData.url) {
          const finalUrl = serverData.tg_url || serverData.url;
          photoEntry.cdnUrl = finalUrl;
          photoEntry.uploading = false;
          renderMemoriesPreviewsGrid();
          updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);
          if (currentPortalUser) saveUserFormData(currentPortalUser);
          if (onDone) onDone();
        }
      })
        .catch(() => {
          photoEntry.uploading = false;
          renderMemoriesPreviewsGrid();
          updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);
          if (currentPortalUser) saveUserFormData(currentPortalUser);
          if (onDone) onDone();
        });
    };
    reader.readAsDataURL(file);
  }

  if (creatorInputMemoriesPhotos) {
    creatorInputMemoriesPhotos.addEventListener('change', (e) => {
      const files = Array.from(e.target.files || []);
      if (files.length === 0) return;

      const statusEl = document.getElementById('memories-photos-status');
      if (statusEl) {
        statusEl.textContent = `⏳ Loading ${files.length} photo${files.length > 1 ? 's' : ''}...`;
        statusEl.style.color = '#ffd700';
      }

      let doneCount = 0;
      files.forEach(file => {
        uploadMemoryFile(file, () => {
          doneCount++;
          if (doneCount === files.length) {
            renderMemoriesPreviewsGrid();
          }
        });
      });

      // Reset so same files can be re-selected
      e.target.value = '';
    });
  }

  if (btnAddMemoryUrl && creatorInputMemoryUrlSingle) {
    btnAddMemoryUrl.addEventListener('click', () => {
      const url = creatorInputMemoryUrlSingle.value.trim();
      if (url && (url.startsWith('http://') || url.startsWith('https://'))) {
        userMemoriesPhotos.push({ cdnUrl: url, localUrl: url, uploading: false });
        creatorInputMemoryUrlSingle.value = '';
        renderMemoriesPreviewsGrid();
        updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);
        if (currentPortalUser) saveUserFormData(currentPortalUser);
        if (typeof updateWizardValidation === 'function') updateWizardValidation();
      }
    });
  }

  // ===== STEP 3: CUSTOM CHAT QUESTIONS BUILDER =====
  const DEFAULT_QUESTIONS_PRESETS = [
    {
      question: "Hey prettiest girl... 💕 Do you know who is the luckiest guy in the entire universe today? (Hint: The one typing this for you ❤️)",
      suggestions: ["You are! 🥰", "My handsome boy ❤️", "Aww so sweet! 💕"]
    },
    {
      question: "What is the one thing that made you smile the most this past year? 🥰",
      suggestions: ["Being with you! ❤️", "All our cute calls 📱", "Your sweet surprises 🎁"]
    },
    {
      question: "If you could make one magical birthday wish right this second, what would it be? ✨",
      suggestions: ["To stay by your side forever 💕", "Lots of happiness & love 🌸", "A big tight hug right now! 🫂"]
    },
    {
      question: "What is your absolute favorite memory of us together so far? 💕",
      suggestions: ["Every moment with you 🥰", "Our late night talks 🌙", "Our first date 🌹"]
    },
    {
      question: "Are you ready to step into your grand 3D birthday surprise wonderland now, my princess? 👑🎂",
      suggestions: ["Yes, take me there! ✨", "Can't wait! 🎉", "Let's celebrate! 💖"]
    }
  ];

  let userCustomQuestions = JSON.parse(JSON.stringify(DEFAULT_QUESTIONS_PRESETS));

  function renderQuestionsBuilder() {
    const listEl = document.getElementById('questions-list');
    if (!listEl) return;

    listEl.innerHTML = '';
    userCustomQuestions.forEach((qObj, idx) => {
      const card = document.createElement('div');
      card.className = 'question-item-card';
      const numStr = String(idx + 1).padStart(2, '0');
      const qText = typeof qObj === 'string' ? qObj : (qObj.question || '');
      card.innerHTML = `
        <div class="question-item-top">
          <span class="question-number-badge"><i class="fa-solid fa-comments"></i> Question ${numStr}</span>
          ${userCustomQuestions.length > 1 ? `<button type="button" class="btn-delete-question" data-idx="${idx}" title="Delete Question"><i class="fa-solid fa-trash-can"></i></button>` : ''}
        </div>
        <div class="form-field full-width" style="margin-top: 6px;">
          <input type="text" class="question-text-input" data-idx="${idx}" placeholder="Write your lovely question here..." value="${qText.replace(/"/g, '&quot;')}" style="width: 100%; padding: 10px 14px; border-radius: 12px; background: rgba(255,255,255,0.06); border: 1.5px solid rgba(255,117,140,0.25); color: #fff; font-size: 0.9rem;">
        </div>
      `;
      listEl.appendChild(card);
    });

    // Input listeners
    listEl.querySelectorAll('.question-text-input').forEach(inp => {
      inp.addEventListener('input', (e) => {
        const idx = parseInt(e.target.dataset.idx, 10);
        if (userCustomQuestions[idx] !== undefined) {
          if (typeof userCustomQuestions[idx] === 'string') {
            userCustomQuestions[idx] = e.target.value;
          } else {
            userCustomQuestions[idx].question = e.target.value;
          }
          if (currentPortalUser) saveUserFormData(currentPortalUser);
          updateWizardValidation();
        }
      });
    });

    // Delete listeners
    listEl.querySelectorAll('.btn-delete-question').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.currentTarget.dataset.idx, 10);
        if (!isNaN(idx)) {
          userCustomQuestions.splice(idx, 1);
          renderQuestionsBuilder();
          if (currentPortalUser) saveUserFormData(currentPortalUser);
          updateWizardValidation();
        }
      });
    });

    updateWizardValidation();
  }

  const btnAddQuestion = document.getElementById('btn-add-question');
  if (btnAddQuestion) {
    btnAddQuestion.addEventListener('click', () => {
      const nextNum = userCustomQuestions.length + 1;
      userCustomQuestions.push({
        question: `Sweet Question ${nextNum}: What brings the biggest smile to your face? 💕`,
        suggestions: ["Being with you! ❤️", "Your warm hugs 🤗", "Sweet surprises ✨"]
      });
      renderQuestionsBuilder();
      if (currentPortalUser) saveUserFormData(currentPortalUser);
      if (window.birthdayAudio) {
        try { window.birthdayAudio.playPop(); } catch(e) {}
      }
    });
  }

  // ===== 4-STEP WIZARD CONTROLLER & VALIDATION =====
  let currentWizardStep = 1;
  let wizardToastTimer = null;

  function showWizardToast(msg) {
    const toast = document.getElementById('wizard-toast');
    const toastMsg = document.getElementById('wizard-toast-msg');
    if (!toast || !toastMsg) return;
    toastMsg.textContent = msg;
    toast.classList.remove('hidden');
    if (wizardToastTimer) clearTimeout(wizardToastTimer);
    wizardToastTimer = setTimeout(() => {
      toast.classList.add('hidden');
    }, 4500);
  }

  function isStep1Valid() {
    const nameVal = creatorInputName ? creatorInputName.value.trim() : '';
    const wishVal = creatorInputWish ? creatorInputWish.value.trim() : '';
    const hasPhoto = Boolean(currentPhotoDataUrl || (creatorInputPhotoUrl && creatorInputPhotoUrl.value.trim()));
    return Boolean(nameVal && wishVal && hasPhoto);
  }

  function showStep1ValidationToast() {
    const missing = [];
    const nameVal = creatorInputName ? creatorInputName.value.trim() : '';
    const wishVal = creatorInputWish ? creatorInputWish.value.trim() : '';
    const hasPhoto = Boolean(currentPhotoDataUrl || (creatorInputPhotoUrl && creatorInputPhotoUrl.value.trim()));

    if (!nameVal) missing.push("Celebrant's Real Name");
    if (!wishVal) missing.push("Birthday Message / Love Letter");
    if (!hasPhoto) missing.push("Main Portrait Photo");

    if (missing.length > 0) {
      showWizardToast(`⚠️ Please fill: ${missing.join(', ')}`);
    }
  }

  function isStep2Valid() {
    return Array.isArray(userSafarnamaChapters) && userSafarnamaChapters.length >= 1 &&
      userSafarnamaChapters.some(c => (c.heading && c.heading.trim()) || (c.description && c.description.trim()));
  }

  function isStep3Valid() {
    return Array.isArray(userCustomQuestions) && userCustomQuestions.length >= 1 &&
      userCustomQuestions.some(q => (typeof q === 'string' ? q.trim() : (q.question && q.question.trim())));
  }

  function updateWizardValidation() {
    const btnNext1 = document.getElementById('wizard-btn-next-1');
    if (btnNext1) {
      btnNext1.classList.toggle('disabled', !isStep1Valid());
    }

    const btnNext2 = document.getElementById('wizard-btn-next-2');
    if (btnNext2) {
      btnNext2.classList.toggle('disabled', !isStep2Valid());
    }

    const btnNext3 = document.getElementById('wizard-btn-next-3');
    if (btnNext3) {
      btnNext3.classList.toggle('disabled', !isStep3Valid());
    }
  }

  function goToWizardStep(stepNum) {
    currentWizardStep = stepNum;

    // 1. Update step containers
    for (let i = 1; i <= 4; i++) {
      const stepEl = document.getElementById(`wizard-step-${i}`);
      if (stepEl) {
        if (i === stepNum) {
          stepEl.classList.add('wizard-step-active');
        } else {
          stepEl.classList.remove('wizard-step-active');
        }
      }
    }

    // 2. Update progress indicators
    const progressSteps = document.querySelectorAll('.wizard-progress-step');
    progressSteps.forEach(ps => {
      const s = parseInt(ps.getAttribute('data-step'), 10);
      if (s === stepNum) {
        ps.className = 'wizard-progress-step active';
      } else if (s < stepNum) {
        ps.className = 'wizard-progress-step completed';
      } else {
        ps.className = 'wizard-progress-step';
      }
    });

    const progressLines = document.querySelectorAll('.wizard-progress-line');
    progressLines.forEach(pl => {
      const after = parseInt(pl.getAttribute('data-after'), 10);
      if (after < stepNum) {
        pl.classList.add('completed');
      } else {
        pl.classList.remove('completed');
      }
    });

    // 3. Scroll dashboard to top
    if (portalCreatorDashboard) {
      portalCreatorDashboard.scrollTo({ top: 0, behavior: 'smooth' });
    }

    updateWizardValidation();
  }

  // Progress step bar clicks
  document.querySelectorAll('.wizard-progress-step').forEach(ps => {
    ps.addEventListener('click', () => {
      const targetStep = parseInt(ps.getAttribute('data-step'), 10);
      if (targetStep < currentWizardStep) {
        goToWizardStep(targetStep);
      } else if (targetStep === currentWizardStep) {
        // already here
      } else {
        if (currentWizardStep === 1 && !isStep1Valid()) {
          showStep1ValidationToast();
          return;
        }
        if ((currentWizardStep === 2 || targetStep > 2) && !isStep2Valid()) {
          showWizardToast("⚠️ Please add at least 1 Safarnama chapter first!");
          return;
        }
        if ((currentWizardStep === 3 || targetStep > 3) && !isStep3Valid()) {
          showWizardToast("⚠️ Please add at least 1 Chat Question first!");
          return;
        }
        goToWizardStep(targetStep);
      }
    });
  });

  // Step 1 Navigation
  const wizardBtnNext1 = document.getElementById('wizard-btn-next-1');
  if (wizardBtnNext1) {
    wizardBtnNext1.addEventListener('click', () => {
      if (!isStep1Valid()) {
        showStep1ValidationToast();
        return;
      }
      if (currentPortalUser) saveUserFormData(currentPortalUser);
      goToWizardStep(2);
      if (window.birthdayAudio) { try { window.birthdayAudio.playPop(); } catch(e) {} }
    });
  }

  const wizardBtnBack1 = document.getElementById('wizard-btn-back-1');
  if (wizardBtnBack1) {
    wizardBtnBack1.addEventListener('click', () => {
      if (btnLogoutPortal) btnLogoutPortal.click();
    });
  }

  // Step 2 Navigation
  const wizardBtnNext2 = document.getElementById('wizard-btn-next-2');
  if (wizardBtnNext2) {
    wizardBtnNext2.addEventListener('click', () => {
      if (!isStep2Valid()) {
        showWizardToast("⚠️ Please add at least 1 Safarnama chapter!");
        return;
      }
      if (currentPortalUser) saveUserFormData(currentPortalUser);
      goToWizardStep(3);
      if (window.birthdayAudio) { try { window.birthdayAudio.playPop(); } catch(e) {} }
    });
  }

  const wizardBtnBack2 = document.getElementById('wizard-btn-back-2');
  if (wizardBtnBack2) {
    wizardBtnBack2.addEventListener('click', () => {
      goToWizardStep(1);
    });
  }

  // Step 3 Navigation
  const wizardBtnNext3 = document.getElementById('wizard-btn-next-3');
  if (wizardBtnNext3) {
    wizardBtnNext3.addEventListener('click', () => {
      if (!isStep3Valid()) {
        showWizardToast("⚠️ Please add at least 1 Chat Question!");
        return;
      }
      if (currentPortalUser) saveUserFormData(currentPortalUser);
      goToWizardStep(4);
      if (window.birthdayAudio) { try { window.birthdayAudio.playPop(); } catch(e) {} }
    });
  }

  const wizardBtnBack3 = document.getElementById('wizard-btn-back-3');
  if (wizardBtnBack3) {
    wizardBtnBack3.addEventListener('click', () => {
      goToWizardStep(2);
    });
  }

  // Step 4 Navigation
  const wizardBtnBack4 = document.getElementById('wizard-btn-back-4');
  if (wizardBtnBack4) {
    wizardBtnBack4.addEventListener('click', () => {
      const confirmEdit = window.confirm("⚠️ Note: Agar aap details badalte hain, to link update karne ke liye aapko wapas Step 4 par aakar 'Generate Surprise Link' par click karna hoga.\n\nKya aap details edit karna chahte hain?");
      if (!confirmEdit) return;
      goToWizardStep(3);
      showWizardToast("✏️ Edit mode: Changes save karne ke baad Step 4 par aakar link dubara generate karein.");
    });
  }

  const wizardBtnLogout4 = document.getElementById('wizard-btn-logout-4');
  if (wizardBtnLogout4) {
    wizardBtnLogout4.addEventListener('click', () => {
      if (btnLogoutPortal) btnLogoutPortal.click();
    });
  }

  // Real-time input validation listeners for Step 1
  if (creatorInputName) {
    creatorInputName.addEventListener('input', () => updateWizardValidation());
  }
  if (creatorInputWish) {
    creatorInputWish.addEventListener('input', () => updateWizardValidation());
  }

  // Initialize questions builder
  renderQuestionsBuilder();

  // 7. Generate Surprise Link Form Submission
  // 7. Generate Surprise Link Form Submission
  let linkExpiryTimerInterval = null;

  function startLinkExpiryCountdown(expiresAt, userKey) {
    if (linkExpiryTimerInterval) clearInterval(linkExpiryTimerInterval);

    const expDate = new Date(expiresAt);
    const dateOptions = { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
    const dateFormatted = expDate.toLocaleString('en-US', dateOptions);

    const exactDateEl = document.getElementById('expiry-exact-date');
    if (exactDateEl) {
      exactDateEl.textContent = `Active Until: ${dateFormatted}`;
    }

    function tick() {
      const now = Date.now();
      const diff = expiresAt - now;

      if (diff <= 0) {
        clearInterval(linkExpiryTimerInterval);
        handleLinkAutoExpiry(userKey);
        return;
      }

      const h = Math.floor(diff / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const s = Math.floor((diff % (1000 * 60)) / 1000);

      const chipH = document.getElementById('exp-chip-hours');
      const chipM = document.getElementById('exp-chip-mins');
      const chipS = document.getElementById('exp-chip-secs');

      if (chipH) chipH.textContent = `${h}h`;
      if (chipM) chipM.textContent = `${m.toString().padStart(2, '0')}m`;
      if (chipS) chipS.textContent = `${s.toString().padStart(2, '0')}s`;
    }

    tick();
    linkExpiryTimerInterval = setInterval(tick, 1000);
  }

  function handleLinkAutoExpiry(userKey) {
    if (!userKey) userKey = (currentPortalUser || localStorage.getItem('birthday_portal_session') || '').toLowerCase();

    // Purge user data from localStorage
    if (userKey) {
      try {
        localStorage.removeItem(`birthday_userdata_${userKey}`);
        localStorage.removeItem(`birthday_link_expires_${userKey}`);
        localStorage.removeItem(`birthday_link_generated_${userKey}`);
        localStorage.removeItem(`birthday_last_generated_link_${userKey}`);
        localStorage.removeItem(`birthday_user_registered_${userKey}`);
      } catch(e) {}
    }
    try {
      localStorage.removeItem('birthday_custom_photo');
      localStorage.removeItem('birthday_portal_session');
    } catch(e) {}

     // Send server purge request
     try {
       fetch(`${API_BASE}/api/expire_user`, {
         method: 'POST',
         headers: authHeaders(),
         body: JSON.stringify({ username: userKey, reason: '48hr_link_expired' })
       }).catch(() => {});
     } catch(e) {}

    // Update UI
    const expCard = document.getElementById('link-expiry-card');
    if (expCard) {
      expCard.innerHTML = `
        <div style="text-align:center; padding:12px; color:#ff4d6d;">
          <div style="font-size:2rem; margin-bottom:6px;">⌛💔</div>
          <strong style="font-size:1.05rem;">Link Expired & Data Deleted Permanently</strong>
          <p style="font-size:0.83rem; color:rgba(255,255,255,0.8); margin:6px 0 0;">
            The 48-hour active window has finished. All uploaded photos, love letters, and surprise URLs have been permanently purged from server and Telegram.
          </p>
        </div>
      `;
    }
  }

  if (creatorSurpriseForm) {
    creatorSurpriseForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      const nameVal = (creatorInputName ? creatorInputName.value.trim() : '') || 'My Love';
      const nickVal = (creatorInputNickname ? creatorInputNickname.value.trim() : '') || '';
      const ageVal = (creatorInputAge ? creatorInputAge.value.trim() : '') || '';
      const themeVal = (creatorInputTheme ? creatorInputTheme.value : '') || 'rose-glamour';
      const wishVal = (creatorInputWish ? creatorInputWish.value.trim() : '') || 'Happy Birthday!';

      // Update active app state
      celebrantName = nameVal;
      celebrantAge = ageVal;
      customWish = wishVal;
      activeTheme = themeVal;
      celebrantFont = (creatorInputFont ? creatorInputFont.value : celebrantFont) || 'outfit';
      updateCelebrantInfo();
      applyTheme(themeVal);

      const genAt = Date.now();
      const expAt = genAt + (48 * 60 * 60 * 1000); // 48 Hours
      const uKey = currentPortalUser || 'user';

      // Gather all memories photos (accepts both server URLs and local data URLs)
      const allMemoriesUrls = (userMemoriesPhotos || [])
        .map(p => {
          if (!p) return null;
          if (typeof p === 'string') return p;
          if (typeof p === 'object') return p.cdnUrl || p.localUrl || null;
          return null;
        })
        .filter(Boolean);

      // Button loading state
      const btnGenerate = document.getElementById('btn-generate-surprise-link');
      if (btnGenerate) {
        btnGenerate.disabled = true;
        btnGenerate.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Generating Short Link...';
      }

      // Build surprise payload — ALL data stored server-side
      const surprisePayload = {
        username: uKey,
        surprise: '1',
        u: uKey,
        mode: selectedCreatorMode,
        name: nameVal,
        nickname: nickVal,
        age: ageVal,
        theme: themeVal,
        font: celebrantFont,
        wish: wishVal,
        photo: currentPhotoDataUrl || '',
        memories: allMemoriesUrls,
        safarnama: userSafarnamaChapters || [],
        questions: userCustomQuestions || [],
        upi: (creatorInputUpi ? creatorInputUpi.value.trim() : '') || creatorUpiId || '',
        exp: expAt,
        gen_at: genAt
      };

      // Existing token reuse on regeneration
      const existingToken = localStorage.getItem(`birthday_short_token_${uKey}`);
      if (existingToken) surprisePayload.token = existingToken;

      saveUserFormData(uKey);

       try {
         const res = await fetch(`${API_BASE}/api/save_surprise`, {
           method: 'POST',
           headers: authHeaders(),
           body: JSON.stringify(surprisePayload)
         });
        const json = await res.json();
        const token = json.token;
        const currentUrl = new URL(window.location.href);
        currentUrl.search = '';
        currentUrl.hash = '';
        const shortLink = `${currentUrl.origin}${currentUrl.pathname}?s=${token}`;

        // Save token for reuse
        localStorage.setItem(`birthday_short_token_${uKey}`, token);
        localStorage.setItem(`birthday_link_expires_${uKey}`, expAt.toString());
        localStorage.setItem(`birthday_link_generated_${uKey}`, genAt.toString());
        localStorage.setItem(`birthday_last_generated_link_${uKey}`, shortLink);

        if (finalSurpriseLinkInput) finalSurpriseLinkInput.value = shortLink;
        if (generatedLinkBox) {
          generatedLinkBox.classList.remove('hidden');
          generatedLinkBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        startLinkExpiryCountdown(expAt, uKey);

         // Also notify bot server about expiry (legacy compat)
         fetch(`${API_BASE}/api/save_link_expiry`, {
           method: 'POST',
           headers: authHeaders(),
           body: JSON.stringify({ username: uKey, link_generated_at: genAt, link_expires_at: expAt, link: shortLink })
         }).catch(() => {});

      } catch(err) {
        // Fallback: build a regular URL if server is unreachable
        const currentUrl = new URL(window.location.href);
        currentUrl.search = '';
        const fallbackParams = new URLSearchParams();
        fallbackParams.set('surprise', '1');
        fallbackParams.set('u', uKey);
        fallbackParams.set('name', nameVal);
        if (nickVal) fallbackParams.set('nickname', nickVal);
        if (ageVal) fallbackParams.set('age', ageVal);
        fallbackParams.set('theme', themeVal);
        fallbackParams.set('font', celebrantFont);
        fallbackParams.set('wish', wishVal);
        if (creatorUpiId || (creatorInputUpi && creatorInputUpi.value.trim())) {
          fallbackParams.set('upi', (creatorInputUpi ? creatorInputUpi.value.trim() : '') || creatorUpiId);
        }
        if (currentPhotoDataUrl && currentPhotoDataUrl.startsWith('http')) fallbackParams.set('photo', currentPhotoDataUrl);
        fallbackParams.set('exp', expAt.toString());
        const fallbackLink = `${currentUrl.origin}${currentUrl.pathname}?${fallbackParams.toString()}`;
        if (finalSurpriseLinkInput) finalSurpriseLinkInput.value = fallbackLink;
        if (generatedLinkBox) {
          generatedLinkBox.classList.remove('hidden');
          generatedLinkBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
        startLinkExpiryCountdown(expAt, uKey);
      } finally {
        if (btnGenerate) {
          btnGenerate.disabled = false;
          btnGenerate.innerHTML = '<span class="btn-shine"></span><i class="fa-solid fa-wand-magic-sparkles"></i> Generate Surprise Link 🎁✨';
        }
      }

      if (window.confetti) {
        window.confetti({ particleCount: 70, spread: 80, origin: { y: 0.7 } });
      }
      if (window.birthdayAudio) {
        try { window.birthdayAudio.playFanfare(); } catch(e) {}
      }
    });
  }

  // 8. Copy Final Link Button
  if (btnCopyFinalLink && finalSurpriseLinkInput) {
    btnCopyFinalLink.addEventListener('click', () => {
      finalSurpriseLinkInput.select();
      finalSurpriseLinkInput.setSelectionRange(0, 99999);
      try {
        navigator.clipboard.writeText(finalSurpriseLinkInput.value).then(() => {
          if (finalCopyFeedback) {
            finalCopyFeedback.classList.add('show');
            setTimeout(() => finalCopyFeedback.classList.remove('show'), 3500);
          }
        }).catch(() => {
          document.execCommand('copy');
          if (finalCopyFeedback) {
            finalCopyFeedback.classList.add('show');
            setTimeout(() => finalCopyFeedback.classList.remove('show'), 3500);
          }
        });
      } catch(err) {
        document.execCommand('copy');
        if (finalCopyFeedback) {
          finalCopyFeedback.classList.add('show');
          setTimeout(() => finalCopyFeedback.classList.remove('show'), 3500);
        }
      }
    });
  }

  // 9. Launch & Preview Surprise Now
  if (btnLaunchPreview) {
    btnLaunchPreview.addEventListener('click', () => {
      // Re-apply all personalization before launching preview
      updateCelebrantInfo();
      applyTheme(activeTheme);
      updateMemoriesPhoto(currentPhotoDataUrl, userMemoriesPhotos);

      if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
      if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      if (curtainContainer) curtainContainer.style.display = 'flex';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

   // 10. Logout from Creator Dashboard
   if (btnLogoutPortal) {
     btnLogoutPortal.addEventListener('click', () => {
       clearSessionToken();
       try {
         localStorage.removeItem('birthday_portal_session');
       } catch(e) {}
       currentPortalUser = null;
       // Strip any surprise-link params (?s=, ?preview=, etc.) so a leftover
       // link param doesn't force the 3D curtain open instead of landing.
       clearSurpriseLinkParamsFromUrl();
       if (curtainContainer) {
         curtainContainer.style.display = 'none';
         curtainContainer.classList.remove('opened');
       }
       document.documentElement.classList.add('route-portal-landing');
       document.documentElement.classList.remove('route-surprise-curtain', 'route-creator-dashboard');
       if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
       if (portalLandingScreen) portalLandingScreen.classList.remove('hidden');
       if (generatedLinkBox) generatedLinkBox.classList.add('hidden');
       window.scrollTo({ top: 0, behavior: 'smooth' });
     });
   }


    // Modal backdrop click handlers
  [customizeModal, shareModal, giftModal, arcadeOverModal, photoBoothModal, polaroidsModal, chatHistoryModal, modalBookMemories, modalBookSafarnama, portalLoginModal].forEach(modal => {
    if (modal) {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          modal.classList.remove('show');
        }
      });
    }
  });

  // Check URL parameters and session state on load
  function checkInitialPortalState() {
    const params = new URLSearchParams(window.location.search || window.location.hash.replace(/^#/, '?'));
    const isDirectSurpriseLink = params.has('s') || params.has('surprise') || params.has('name') || params.has('preview') || params.has('demo');

    // 1. Check if recipient opened an expired 48h surprise link
    if (params.has('exp')) {
      const expTs = parseInt(params.get('exp'), 10);
      if (expTs && Date.now() >= expTs) {
        // Link has reached 48h expiration!
        const expiredOverlay = document.getElementById('expired-link-overlay');
        if (expiredOverlay) expiredOverlay.classList.remove('hidden');
        if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
        if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
        if (curtainContainer) curtainContainer.style.display = 'none';
        return;
      }
    }

    // 2. Decode custom Safarnama chapters from URL if present
    if (params.has('safarnama')) {
      try {
        const decoded = JSON.parse(decodeURIComponent(params.get('safarnama')));
        if (Array.isArray(decoded) && decoded.length > 0) {
          userSafarnamaChapters = decoded;
        }
      } catch(e) {}
    }

    if (isDirectSurpriseLink) {
      if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
      if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      if (curtainContainer) {
        curtainContainer.style.display = 'flex';
        curtainContainer.classList.remove('opened');
      }
      trackRecipientActivity('link_opened', 'Opened magical birthday surprise link 🚀', '🚀');
    } else {
      // Normal visit (non-shareable link): Always hide the curtain
      if (curtainContainer) {
        curtainContainer.style.display = 'none';
        curtainContainer.classList.remove('opened');
      }
      renderSafarnamaBuilder();
      let savedSession = null;
      try { savedSession = localStorage.getItem('birthday_portal_session'); } catch(e) {}

      if (savedSession) {
        currentPortalUser = savedSession.toLowerCase();
        if (loggedUserName) loggedUserName.textContent = savedSession;
        if (portalLandingScreen) portalLandingScreen.classList.add('hidden');
        if (portalCreatorDashboard) portalCreatorDashboard.classList.remove('hidden');
        initCreatorLiveTracker();
        
        // Restore form data silently on page reload
        setTimeout(() => {
          restoreUserFormData(currentPortalUser);

          // Check if user has active link countdown or expired
          const savedExp = localStorage.getItem(`birthday_link_expires_${currentPortalUser}`);
          if (savedExp) {
            const expNum = parseInt(savedExp, 10);
            if (Date.now() >= expNum) {
              handleLinkAutoExpiry(currentPortalUser);
              goToWizardStep(1);
            } else {
              const lastLink = localStorage.getItem(`birthday_last_generated_link_${currentPortalUser}`);
              if (lastLink && finalSurpriseLinkInput) {
                finalSurpriseLinkInput.value = lastLink;
                if (generatedLinkBox) generatedLinkBox.classList.remove('hidden');
                startLinkExpiryCountdown(expNum, currentPortalUser);
                goToWizardStep(4);
              } else {
                goToWizardStep(1);
              }
            }
          } else {
            goToWizardStep(1);
            // Check idle account 72h expiration (48 to 72 hours)
            const regTime = localStorage.getItem(`birthday_user_registered_${currentPortalUser}`);
            if (regTime) {
              const idleDiff = Date.now() - parseInt(regTime, 10);
              if (idleDiff >= 72 * 3600 * 1000) {
                handleLinkAutoExpiry(currentPortalUser);
              }
            }
          }
        }, 400);
      } else {
        if (portalLandingScreen) {
          portalLandingScreen.classList.remove('hidden');
          portalLandingScreen.style.display = 'flex';
        }
        if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      }
    }
  }

  /* =========================================================
     DELETE ACCOUNT MODAL LOGIC
     ========================================================= */
  const deleteAccountModal = document.getElementById('delete-account-modal');
  const closeDeleteModal = document.getElementById('close-delete-modal');
  const btnOpenDeleteModal = document.getElementById('btn-open-delete-modal');
  const btnConfirmDelete = document.getElementById('btn-confirm-delete');
  const btnCancelDelete = document.getElementById('btn-cancel-delete');
  const deleteConfirmPassword = document.getElementById('delete-confirm-password');
  const btnToggleDeletePwd = document.getElementById('btn-toggle-delete-pwd');
  const deleteFeedbackMsg = document.getElementById('delete-feedback-msg');
  const deleteProgressWrap = document.getElementById('delete-progress-wrap');
  const deleteProgressFill = document.getElementById('delete-progress-fill');
  const deleteProgressLabel = document.getElementById('delete-progress-label');
  const deleteStepsList = document.getElementById('delete-steps-list');
  const deleteConfirmSection = document.getElementById('delete-confirm-section');
  const deleteModalFooter = document.getElementById('delete-modal-footer');
  const deleteDoneState = document.getElementById('delete-done-state');

  function populateDeletePreview() {
    const username = currentPortalUser || (localStorage.getItem('birthday_portal_session') || '').toLowerCase();

    // Account Info
    const infoEl = document.getElementById('del-info-items');
    if (infoEl) {
      infoEl.innerHTML = `
        <div class="delete-data-item"><span class="item-label">Username:</span><span class="item-val">${username || 'N/A'}</span></div>
        <div class="delete-data-item"><span class="item-label">Session:</span><span class="item-val">Active ✅</span></div>
        <div class="delete-data-item"><span class="item-label">Registered:</span><span class="item-val">Yes (localStorage + Server)</span></div>`;
    }

    // Photo & Name
    const photoEl = document.getElementById('del-photo-items');
    if (photoEl) {
      let name = (creatorInputName && creatorInputName.value) ? creatorInputName.value : celebrantName || 'Not set';
      let hasPhoto = !!currentPhotoDataUrl;
      photoEl.innerHTML = `
        <div class="delete-data-item"><span class="item-label">Celebrant Name:</span><span class="item-val">${name}</span></div>
        <div class="delete-data-item"><span class="item-label">Portrait Photo:</span><span class="item-val">${hasPhoto ? '✅ Uploaded' : '<span class="no-data-tag">None</span>'}</span></div>
        <div class="delete-data-item"><span class="item-label">Saved Form Data:</span><span class="item-val">${localStorage.getItem(`birthday_userdata_${username}`) ? '✅ Saved' : '<span class="no-data-tag">None</span>'}</span></div>`;
    }

    // Chat Answers
    const chatEl = document.getElementById('del-chat-items');
    if (chatEl) {
      const history = getSavedChatHistory();
      if (history.length > 0) {
        let html = `<div style="margin-bottom:6px;color:#ffb3c1;">${history.length} saved answers will be deleted:</div>`;
        history.slice(0, 3).forEach((h, i) => {
          html += `<div class="delete-data-item"><span class="item-label">Q${i+1}:</span><span class="item-val" style="opacity:0.8;">"${(h.reply||'').substring(0,40)}..."</span></div>`;
        });
        chatEl.innerHTML = html;
      } else {
        chatEl.innerHTML = '<span class="no-data-tag">No chat answers saved</span>';
      }
    }

    // Links & Settings
    const linksEl = document.getElementById('del-links-items');
    if (linksEl) {
      const link = finalSurpriseLinkInput && finalSurpriseLinkInput.value ? finalSurpriseLinkInput.value.substring(0, 50) + '...' : null;
      linksEl.innerHTML = `
        <div class="delete-data-item"><span class="item-label">Generated Link:</span><span class="item-val">${link || '<span class="no-data-tag">None</span>'}</span></div>
        <div class="delete-data-item"><span class="item-label">Theme:</span><span class="item-val">${activeTheme || 'Default'}</span></div>
        <div class="delete-data-item"><span class="item-label">localStorage keys:</span><span class="item-val">All data wiped</span></div>`;
    }
  }

  if (btnOpenDeleteModal) {
    btnOpenDeleteModal.addEventListener('click', () => {
      populateDeletePreview();
      if (deleteAccountModal) deleteAccountModal.classList.add('show');
    });
  }

  if (closeDeleteModal) {
    closeDeleteModal.addEventListener('click', () => {
      if (deleteAccountModal) deleteAccountModal.classList.remove('show');
    });
  }

  if (btnCancelDelete) {
    btnCancelDelete.addEventListener('click', () => {
      if (deleteAccountModal) deleteAccountModal.classList.remove('show');
    });
  }

  if (btnToggleDeletePwd && deleteConfirmPassword) {
    btnToggleDeletePwd.addEventListener('click', () => {
      const isPwd = deleteConfirmPassword.type === 'password';
      deleteConfirmPassword.type = isPwd ? 'text' : 'password';
      btnToggleDeletePwd.innerHTML = isPwd ? '<i class="fa-solid fa-eye-slash"></i>' : '<i class="fa-solid fa-eye"></i>';
    });
  }

  async function runDeleteSequence(username, password) {
    const steps = [
      { label: 'Verifying password & identity...' },
      { label: 'Wiping saved form data...' },
      { label: 'Clearing chat history...' },
      { label: 'Removing session & credentials...' },
      { label: 'Sending Telegram notification...' },
      { label: 'Scheduling permanent 24hr deletion...' },
      { label: 'Finalizing account removal...' }
    ];

    if (deleteConfirmSection) deleteConfirmSection.classList.add('hidden');
    if (deleteModalFooter) deleteModalFooter.classList.add('hidden');
    if (deleteProgressWrap) deleteProgressWrap.classList.remove('hidden');
    if (deleteStepsList) deleteStepsList.innerHTML = '';

    const addStep = (label, status = 'pending') => {
      if (!deleteStepsList) return;
      const el = document.createElement('div');
      el.className = `delete-step-item ${status}`;
      el.textContent = label;
      deleteStepsList.appendChild(el);
      return el;
    };

    const setProgress = (pct, label) => {
      if (deleteProgressFill) deleteProgressFill.style.width = `${pct}%`;
      if (deleteProgressLabel) deleteProgressLabel.textContent = label;
    };

    for (let i = 0; i < steps.length; i++) {
      const stepEl = addStep(steps[i].label, 'pending');
      setProgress(Math.round(((i + 0.5) / steps.length) * 100), steps[i].label);
      await new Promise(r => setTimeout(r, 600 + Math.random() * 400));

      if (i === 0) {
        // 🔒 SECURITY: Verify password via SERVER (never store/compare locally)
        try {
          const authRes = await fetch(`${API_BASE}/api/auth`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: username.toLowerCase().trim(), password: password })
          });
          const authJson = await authRes.json();
          if (!authRes.ok || authJson.status !== 'success') {
            if (stepEl) { stepEl.className = 'delete-step-item'; stepEl.textContent = '❌ Wrong password — deletion cancelled!'; }
            if (deleteProgressWrap) deleteProgressWrap.classList.add('hidden');
            if (deleteConfirmSection) deleteConfirmSection.classList.remove('hidden');
            if (deleteModalFooter) deleteModalFooter.classList.remove('hidden');
            if (deleteFeedbackMsg) {
              deleteFeedbackMsg.textContent = '❌ Wrong password! Enter the correct password to delete.';
              deleteFeedbackMsg.classList.remove('hidden');
            }
            return;
          }
        } catch(authErr) {
          if (stepEl) { stepEl.className = 'delete-step-item'; stepEl.textContent = '❌ Server connection error!'; }
          if (deleteProgressWrap) deleteProgressWrap.classList.add('hidden');
          if (deleteConfirmSection) deleteConfirmSection.classList.remove('hidden');
          if (deleteModalFooter) deleteModalFooter.classList.remove('hidden');
          return;
        }
      }

      if (i === 1) {
        // Clear form data from localStorage
        try { localStorage.removeItem(`birthday_userdata_${username}`); } catch(e) {}
      }

      if (i === 2) {
        // Clear chat history
        try { localStorage.removeItem('birthday_chat_history'); } catch(e) {}
      }

      if (i === 3) {
        // Remove session & local data (no passwords stored locally anymore)
        try {
          localStorage.removeItem('birthday_portal_session');
          localStorage.removeItem('birthday_custom_photo');
          localStorage.removeItem('birthday_api_session_token');
          // Add to banned list
          let banned = JSON.parse(localStorage.getItem('birthday_banned_users') || '[]');
          if (!banned.includes(username)) banned.push(username);
          localStorage.setItem('birthday_banned_users', JSON.stringify(banned));
        } catch(e) {}
      }

       if (i === 4) {
         // Notify server — server handles Telegram alert securely
         try {
           await fetch(`${API_BASE}/api/delete_user`, {
             method: 'POST',
             headers: authHeaders(),
             body: JSON.stringify({
               username, password,
               celebrant_name: celebrantName
             })
           }).catch(() => {});
         } catch(e) {}
       }

       if (i === steps.length - 1) {
         // Clear session token after final deletion step
         clearSessionToken();
       }

      if (stepEl) stepEl.className = 'delete-step-item done';
      setProgress(Math.round(((i + 1) / steps.length) * 100), i < steps.length - 1 ? steps[i + 1]?.label || 'Completing...' : 'Deletion complete!');
    }

    // Show done state
    await new Promise(r => setTimeout(r, 500));
    if (deleteProgressWrap) deleteProgressWrap.classList.add('hidden');
    if (deleteDoneState) deleteDoneState.classList.remove('hidden');

    // Auto-logout after 3 seconds
    setTimeout(() => {
      if (deleteAccountModal) deleteAccountModal.classList.remove('show');
      currentPortalUser = null;
      if (portalCreatorDashboard) portalCreatorDashboard.classList.add('hidden');
      if (portalLandingScreen) portalLandingScreen.classList.remove('hidden');
      // Reset done state for next time
      if (deleteDoneState) deleteDoneState.classList.add('hidden');
      if (deleteProgressWrap) deleteProgressWrap.classList.add('hidden');
      if (deleteStepsList) deleteStepsList.innerHTML = '';
      if (deleteProgressFill) deleteProgressFill.style.width = '0%';
      if (deleteConfirmSection) deleteConfirmSection.classList.remove('hidden');
      if (deleteModalFooter) deleteModalFooter.classList.remove('hidden');
      if (deleteConfirmPassword) deleteConfirmPassword.value = '';
    }, 4000);
  }

  if (btnConfirmDelete) {
    btnConfirmDelete.addEventListener('click', async () => {
      const username = currentPortalUser || (localStorage.getItem('birthday_portal_session') || '').toLowerCase();
      const password = deleteConfirmPassword ? deleteConfirmPassword.value : '';

      if (!password) {
        if (deleteFeedbackMsg) {
          deleteFeedbackMsg.textContent = '⚠️ Please enter your password to confirm deletion.';
          deleteFeedbackMsg.classList.remove('hidden');
        }
        return;
      }
      if (deleteFeedbackMsg) deleteFeedbackMsg.classList.add('hidden');

      await runDeleteSequence(username, password);
    });
  }

  // Auto-save form data when submit button is clicked
  const creatorSurpriseFormEl = document.getElementById('creator-surprise-form');
  if (creatorSurpriseFormEl) {
    creatorSurpriseFormEl.addEventListener('submit', () => {
      if (currentPortalUser) saveUserFormData(currentPortalUser);
    }, true); // capture phase to fire before default
  }

  /* =========================================================
     CREATOR LIVE TRACKER & 2-WAY LIVE CHAT DOCK CONTROLLER
     ========================================================= */
  const trackerOnlineStatus = document.getElementById('tracker-online-status');
  const trackerStatusLabel = document.getElementById('tracker-status-label');
  const activityTimelineList = document.getElementById('activity-timeline-list');
  const btnRefreshTracker = document.getElementById('btn-refresh-tracker');
  const creatorChatBadgeState = document.getElementById('creator-chat-badge-state');
  const btnCreatorOpenLiveChat = document.getElementById('btn-creator-open-live-chat');
  const chatBtnRedDot = document.getElementById('chat-btn-red-dot');
  const creatorChatBtnLabel = document.getElementById('creator-chat-btn-label');
  const creatorLiveChatModal = document.getElementById('creator-live-chat-modal');
  const closeCreatorLiveChat = document.getElementById('close-creator-live-chat');
  const creatorChatMessagesScroll = document.getElementById('creator-chat-messages-scroll');
  const creatorLiveInput = document.getElementById('creator-live-input');
  const btnCreatorSendMsg = document.getElementById('btn-creator-send-msg');
  const creatorChatPartnerName = document.getElementById('creator-chat-partner-name');

  let cachedLiveChatMessages = [];
  let liveTrackerPollInterval = null;

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function renderActivityTimeline(activities) {
    if (!activityTimelineList) return;

    if (!activities || activities.length === 0) {
      activityTimelineList.innerHTML = `
        <div class="activity-empty-state">
          <i class="fa-solid fa-satellite-dish"></i>
          <p>No activity yet. When she opens the link and explores the surprise, live activities will appear here!</p>
        </div>
      `;
      return;
    }

    let html = '';
    // Show most recent activity at the top
    const reversed = [...activities].reverse();
    reversed.forEach((act) => {
      html += `
        <div class="activity-timeline-item">
          <div class="activity-item-icon">${act.icon || '✨'}</div>
          <div class="activity-item-text">
            <strong>${escapeHtml(act.details || act.action || 'Activity')}</strong>
            <span>${act.action ? escapeHtml(act.action.replace(/_/g, ' ')) : ''}</span>
          </div>
          <div class="activity-item-time"><i class="fa-regular fa-clock"></i> ${escapeHtml(act.time || '')}</div>
        </div>
      `;
    });

    activityTimelineList.innerHTML = html;
  }

  function renderCreatorChatMessages(messages) {
    if (!creatorChatMessagesScroll) return;
    cachedLiveChatMessages = messages || [];

    if (!messages || messages.length === 0) {
      creatorChatMessagesScroll.innerHTML = `
        <div class="creator-chat-empty">
          <div style="font-size: 2.2rem; margin-bottom: 8px;">👸💖</div>
          <div><strong>Waiting for her live message...</strong></div>
          <p style="font-size: 0.85rem; opacity: 0.8; margin-top: 4px;">When she sends a follow-up question or message about any Safarnama chapter, it will appear here for you to chat in real time!</p>
        </div>
      `;
      return;
    }

    let html = '';
    messages.forEach((msg) => {
      const isCelebrant = msg.sender === 'celebrant';
      const quoteHtml = msg.quote ? `
        <div class="creator-msg-quote-bubble">
          <div class="quote-mini-heading"><i class="fa-solid fa-feather-pointed"></i> Chapter ${msg.quote.chapterNum || ''}: ${msg.quote.heading || ''}</div>
          <div class="quote-mini-snippet">"${(msg.quote.snippet || '').substring(0, 70)}..."</div>
        </div>
      ` : '';

      html += `
        <div class="creator-msg-row ${isCelebrant ? 'from-celebrant' : 'from-creator'}">
          <div class="creator-bubble-avatar">${isCelebrant ? '👸' : '👦'}</div>
          <div class="creator-msg-bubble ${isCelebrant ? 'celebrant-bubble' : 'creator-bubble'}">
            ${quoteHtml}
            <div class="creator-bubble-text">${msg.text}</div>
            <div class="creator-bubble-time">${msg.time || ''}</div>
          </div>
        </div>
      `;
    });

    creatorChatMessagesScroll.innerHTML = html;
    creatorChatMessagesScroll.scrollTop = creatorChatMessagesScroll.scrollHeight;
  }

   async function fetchLiveProgressData() {
     const userKey = currentPortalUser || (localStorage.getItem('birthday_portal_session') || '').toLowerCase();
     if (!userKey) return;

     try {
       const token = activeSurpriseToken || (localStorage.getItem(`birthday_short_token_${userKey}`) || '');
       const url = `${API_BASE}/api/live_progress?username=${encodeURIComponent(userKey)}${token ? `&token=${encodeURIComponent(token)}` : ''}`;
       const res = await fetch(url, { headers: authHeaders() });
       if (!res.ok) return;
       const data = await res.json();

      if (data && data.status === 'success') {
        const activities = data.activities || [];
        const chat = data.chat || { messages: [], has_unread: false };

        // 1. Update activity feed
        renderActivityTimeline(activities);

        // 2. Update online status
        if (activities.length > 0) {
          const lastAct = activities[activities.length - 1];
          const now = Date.now() / 1000;
          const isRecent = (now - (lastAct.timestamp || now)) < 300; // within 5 mins

          if (trackerOnlineStatus) {
            trackerOnlineStatus.className = isRecent ? 'tracker-status-pill online' : 'tracker-status-pill';
          }
          if (trackerStatusLabel) {
            trackerStatusLabel.textContent = isRecent ? '🟢 Recipient Active Now' : `Last active: ${lastAct.time || 'Recently'}`;
          }
        }

        // 3. Update Live Chat Button state & Red Dot Notification
        const hasMessages = chat.messages && chat.messages.length > 0;
        const hasUnread = chat.has_unread || false;

        if (hasMessages || hasUnread) {
          if (btnCreatorOpenLiveChat) {
            btnCreatorOpenLiveChat.classList.remove('disabled');
          }
          if (creatorChatBtnLabel) {
            creatorChatBtnLabel.textContent = '💬 Open Live Chat with Her 💕';
          }
          if (creatorChatBadgeState) {
            creatorChatBadgeState.innerHTML = '<span style="color:#00ff88;font-weight:700;">🔴 Active!</span>';
          }
          if (chatBtnRedDot) {
            chatBtnRedDot.classList.remove('hidden');
          }
        }

        // 4. Update open modal if visible
        if (creatorLiveChatModal && creatorLiveChatModal.classList.contains('show')) {
          renderCreatorChatMessages(chat.messages || []);
        }
      }
    } catch(e) {}
  }

  function initCreatorLiveTracker() {
    fetchLiveProgressData();
    if (liveTrackerPollInterval) clearInterval(liveTrackerPollInterval);
    liveTrackerPollInterval = setInterval(fetchLiveProgressData, 2500);
  }

  // Refresh Tracker Button Click
  if (btnRefreshTracker) {
    btnRefreshTracker.addEventListener('click', () => {
      initCreatorLiveTracker();
      if (window.birthdayAudio) {
        try { window.birthdayAudio.playPop(); } catch(e) {}
      }
    });
  }

  // Open Creator Live Chat Modal
  if (btnCreatorOpenLiveChat) {
    btnCreatorOpenLiveChat.addEventListener('click', () => {
      if (btnCreatorOpenLiveChat.classList.contains('disabled')) {
        alert("Live chat is waiting for her to initiate! Once she clicks 'Follow in Chat' on any Safarnama chapter, this chat button will activate with a red alert dot! 💕");
        return;
      }

      if (creatorChatPartnerName) {
        const cName = (creatorInputName && creatorInputName.value.trim()) || celebrantName || 'Her';
        creatorChatPartnerName.textContent = `Live 2-Way Chat with ${cName} 💕`;
      }

      if (creatorLiveChatModal) {
        creatorLiveChatModal.classList.add('show');
      }
      if (chatBtnRedDot) {
        chatBtnRedDot.classList.add('hidden');
      }

       // Mark unread as read on server
       const userKey = currentPortalUser || (localStorage.getItem('birthday_portal_session') || '').toLowerCase();
       if (userKey) {
         fetch(`${API_BASE}/api/live_chat_mark_read`, {
           method: 'POST',
           headers: authHeaders(),
           body: JSON.stringify({ username: userKey })
         }).catch(() => {});
       }

      fetchLiveProgressData();
      if (creatorLiveInput) {
        setTimeout(() => creatorLiveInput.focus(), 300);
      }
    });
  }

  if (closeCreatorLiveChat) {
    closeCreatorLiveChat.addEventListener('click', () => {
      if (creatorLiveChatModal) creatorLiveChatModal.classList.remove('show');
    });
  }

  // Send Message from Creator Live Chat
  function sendCreatorLiveReply() {
    if (!creatorLiveInput) return;
    const text = creatorLiveInput.value.trim();
    if (!text) return;

    const userKey = currentPortalUser || (localStorage.getItem('birthday_portal_session') || '').toLowerCase();
    const now = new Date();
    const timeStr = `${now.getHours()}:${String(now.getMinutes()).padStart(2, '0')}`;

    const msgPayload = {
      username: userKey || 'user',
      sender: 'creator',
      text: text,
      quote: null,
      time: timeStr
    };

    creatorLiveInput.value = '';

    // 1. Post to backend server with authentication & token
    const token = activeSurpriseToken || (localStorage.getItem(`birthday_short_token_${userKey}`) || '');
    const sendPayload = Object.assign({}, msgPayload, { token: token });

    fetch(`${API_BASE}/api/live_chat_send`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(sendPayload)
    }).catch(() => {});

    // 2. Broadcast to recipient tab in real time
    if (liveChatBus) {
      try {
        liveChatBus.postMessage({ type: 'live_chat_msg', data: msgPayload });
      } catch(e) {}
    }

    // 3. Render immediately in Creator Chat Window
    cachedLiveChatMessages.push(msgPayload);
    renderCreatorChatMessages(cachedLiveChatMessages);

    // Play chime
    try {
      if (window.birthdayAudio) {
        window.birthdayAudio.init();
        if (typeof window.birthdayAudio.playChimeTone === 'function' && window.birthdayAudio.ctx) {
          window.birthdayAudio.playChimeTone(523.25, window.birthdayAudio.ctx.currentTime, 0.35, 0.25);
        }
      }
    } catch(e) {}
  }

  if (btnCreatorSendMsg) {
    btnCreatorSendMsg.addEventListener('click', sendCreatorLiveReply);
  }

  if (creatorLiveInput) {
    creatorLiveInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendCreatorLiveReply();
      }
    });
  }

  // BroadcastChannel listener in Creator Dashboard
  if (liveChatBus) {
    liveChatBus.addEventListener('message', (event) => {
      const { type, data } = event.data || {};
      if (type === 'activity') {
        fetchLiveProgressData();
      } else if (type === 'live_chat_msg') {
        if (data && data.sender === 'celebrant') {
          // Celebrant sent message! Enable live chat button & red dot alert
          if (btnCreatorOpenLiveChat) btnCreatorOpenLiveChat.classList.remove('disabled');
          if (chatBtnRedDot) chatBtnRedDot.classList.remove('hidden');
          if (creatorChatBtnLabel) creatorChatBtnLabel.textContent = '💬 Open Live Chat with Her 💕';
          if (creatorChatBadgeState) creatorChatBadgeState.innerHTML = '<span style="color:#00ff88;font-weight:700;">🔴 Active!</span>';

          cachedLiveChatMessages.push(data);
          if (creatorLiveChatModal && creatorLiveChatModal.classList.contains('show')) {
            renderCreatorChatMessages(cachedLiveChatMessages);
          }
          if (window.birthdayAudio) {
            try { window.birthdayAudio.playPop(); } catch(e) {}
          }
        }
      }
    });
  }

  parseUrlParams();
  checkInitialPortalState();
  initCreatorLiveTracker();
});



